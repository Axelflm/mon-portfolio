package Model;

public class Reductions {
    private float reducEnfants;
    private float reducRegulier;
    private float reducSenior;

    //Constructeur 1 d'initialisation de valeurs de base
    public Reductions(){
        this.reducEnfants = (float) 0.5;
        this.reducRegulier = (float) 0.1;
        this.reducSenior = (float) 0.25;
    }

    //Constructeur 2 d'initialisation de valeurs défini
    public Reductions(float reducEnfants, float reducRegulier, float reducSenior){
        this.reducEnfants = reducEnfants;
        this.reducRegulier = reducRegulier;
        this.reducSenior = reducSenior;
    }

    //Modification des réductions
    public void setReductions(float reducEnfants, float reducRegulier, float reducSenior){
        this.reducEnfants = reducEnfants;
        this.reducRegulier = reducRegulier;
        this.reducSenior = reducSenior;
    }

    //Obtenir réductions enfant
    public float getReduc(String typeMembre){
        switch (typeMembre) {
            case "enfant":
                return this.reducEnfants;
            case "régulier":
                return this.reducRegulier;
            case "sénior":
                return this.reducSenior;
            default:
                return (float) 0.0;
        }
    }

    //Obtenir réductions enfant
    public float getReducEnfants(){
        return this.reducEnfants;
    }

    //Obtenir réductions enfant
    public float getReducRegulier(){
        return this.reducRegulier;
    }

    //Obtenir réductions enfant
    public float getReducSenior(){
        return this.reducSenior;
    }
}
