package Model;

import DAO.CinemaDAO;
import DAO.FilmDAO;
import DAO.SeanceDAO;

import java.util.ArrayList;

public class Cinema {
    private String logo;
    private String adresse;
    private String nom;
    private ArrayList<Film> catalogue;
    private ArrayList<Seance> seances;
    private Reductions reductions;

    //Constructeur 1 d'initialisation avec valeur de la BDD
    public Cinema(){
        Cinema cinema = CinemaDAO.getCinema();
        if(cinema!=null) {
            this.logo = cinema.getLogo();
            this.adresse = cinema.getAdresse();
            this.nom = cinema.getNom();
            this.reductions = cinema.getAllReduc();
            this.catalogue = FilmDAO.getAllFilms();
            this.seances = SeanceDAO.getAllSeances(catalogue);
        } else {
            this.logo = "img/ece.jpg";
            this.adresse = "10 rue Sextius Michel 75015 Paris France";
            this.nom = "ECE-Cinéma 42";
            this.reductions = new Reductions();
            this.catalogue = new ArrayList<>();
            this.seances = new ArrayList<>();
        }
    }

    //Constructeur 2 d'initialisation de valeurs défini
    public Cinema(String logo, String adresse, String nom, Reductions reductions, ArrayList<Film> catalogue, ArrayList<Seance> seances){
        this.logo = logo;
        this.adresse = adresse;
        this.nom = nom;
        this.reductions = reductions;
        this.catalogue = catalogue;
        this.seances = seances;
    }


    //Modification du logo du cinéma
    public void setLogo(String logo){
        this.logo = logo;
    }

    //Modification de l'adresse du cinéma
    public void setAdresse(String adresse){
        this.adresse = adresse;
    }

    //Modification du nom du cinéma
    public void setNom(String nom){
        this.nom = nom;
    }

    //Obtenir le logo du cinéma
    public String getLogo(){
        return this.logo;
    }

    //Obtenir l'adresse du cinéma
    public String getAdresse(){
        return this.adresse;
    }

    //Obtenir le nom du cinéma
    public String getNom(){
        return this.nom;
    }

    //Obtenir le catalogue du cinéma
    public ArrayList<Film> getCatalogue(){
        return this.catalogue;
    }

    //Obtenir les séances du cinéma
    public ArrayList<Seance> getAllSeances(){
        return this.seances;
    }

    //Obtenir les réductions du cinéma
    public Reductions getAllReduc(){
        return this.reductions;
    }

    public ArrayList<Seance> getSeances(Film film){
        ArrayList<Seance> filmSeances = new ArrayList<>();
        for(Seance seance : this.seances){
            if(seance.getFilm().equals(film)){
                filmSeances.add(seance);
            }
        }
        return filmSeances;
    }
}
