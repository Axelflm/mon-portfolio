package Model;

public class Film {
    private int id;
    private String image;
    private String titre;
    private String realisateur;
    private String duree;
    private float prix;

    //Constructeur d'un film sans id
    public Film(String image, String titre, String realisateur, String duree, float prix){
        this.id = 0; //id = 0 => pas encore créer dans la base de donnée
        this.titre = titre;
        this.image = image;
        this.realisateur = realisateur;
        this.duree = duree;
        this.prix = prix;
    }

    //Constructeur d'un film avec id
    public Film(int id, String image, String titre, String realisateur, String duree, float prix){
        this.id = id;
        this.titre = titre;
        this.image = image;
        this.realisateur = realisateur;
        this.duree = duree;
        this.prix = prix;
    }

    public void setID(int id){
        this.id = id;
    }

    //Modification des attributs du film
    public void setFilm(String image, String titre, String realisateur, String duree, float prix){
        this.titre = titre;
        this.image = image;
        this.realisateur = realisateur;
        this.duree = duree;
        this.prix = prix;
    }

    //Obtenir l'id du film
    public int getId(){
        return this.id;
    }

    //Obtenir le titre du film
    public String getTitre(){
        return this.titre;
    }

    //Obtenir l'image du film
    public String getImage(){
        return this.image;
    }

    //Obtenir le realisateur du film
    public String getRealisateur(){
        return this.realisateur;
    }

    //Obtenir la durée du film
    public String getDuree(){
        return this.duree;
    }

    //Obtenir le prix du film
    public float getPrix(){
        return this.prix;
    }

    @Override
    public String toString() {
        return titre; // Retourne le titre du film
    }
}
