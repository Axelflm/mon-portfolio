package Model;

import DAO.ReservationDAO;
import DAO.UserDAO;

import java.util.ArrayList;

public class Client extends User{
    private ArrayList<Reservation> reservations;
    private String typeClient;
    private float reducPerso;

    //Constructeur 1 d'initialisation de valeurs de base
    public Client(){
        super();
        this.typeClient = "invité";
        this.reducPerso = 0;
        this.reservations = new ArrayList<Reservation>();
    }

    //Constructeur 2 d'initialisation de valeurs données
    public Client(int id, String nom, String prenom, String login, String mdp, ArrayList<Reservation> reservations, String typeClient, float reducPerso){
        super(id, nom, prenom, login, mdp);
        this.typeClient = typeClient;
        this.reducPerso = reducPerso;
        this.reservations = reservations;
    }

    //Modification du type du Membre
    public void setTypeMembre(String typeClient){
        this.typeClient = typeClient;
    }

    //Modification de la réduction du Membre
    public void setReducMembre(float reducPerso){
        this.reducPerso = reducPerso;
    }

    //Modification des réservations du Membre
    public void autoSetReservationsMembre(ArrayList<Seance> seance){
        this.reservations = ReservationDAO.getReservationsClient(seance, this);
    }
    public void setReservationsMembre(ArrayList<Reservation> reservations){
        this.reservations = reservations;
    }

    //Obtenir le type du Membre
    public String getTypeMembre(){
        return this.typeClient;
    }

    //Obtenir la réduction du Membre
    public float getReducMembre(){
        return this.reducPerso;
    }

    public ArrayList<Reservation> getReservations(){
        return this.reservations;
    }


    public void reserver(Seance seance, Client client, int nbBillets, float totalPaiement){
        Reservation reservation = new Reservation(seance, client, nbBillets, totalPaiement);
        int newId = ReservationDAO.createReservation(reservation);
        reservation.setId(newId);
        reservations.add(reservation);
    }

    public void modifierReservation(Reservation reservation, Seance seance, Client client, int nbBillets, float totalPaiement){
        reservation.setReservation(seance, client, nbBillets, totalPaiement);
        ReservationDAO.updateReservation(reservation);
    }

    public void supprReservation(Reservation reservation){
        ReservationDAO.deleteReservation(reservation.getId());
        reservations.remove(reservation);
    }



    public static ArrayList<Client> getAllClients(ArrayList<Seance> seances){
        ArrayList<Client> clients = UserDAO.getAllClients();
        for (Client client : clients) {
            client.setReservationsMembre(ReservationDAO.getReservationsClient(seances, client));
        }
        return clients;
    }
}
