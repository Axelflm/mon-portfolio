package Model;

import DAO.UserDAO;

import java.util.ArrayList;

public abstract class User {
    private int id;
    private String nom;
    private String prenom;
    private String login;
    private String mdp;

    //Constructeur 1 d'initialisation de valeurs de base
    public User(){
        this.id = 0;
        this.nom = "Invité";
        this.prenom = "";
        this.login = "";
        this.mdp = "";
    }

    //Constructeur 2 d'initialisation de valeurs données
    public User(int id, String nom, String prenom, String login, String mdp){
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.login = login;
        this.mdp = mdp;
    }


    //Obtenir l'id du User
    public int getIdUser() {
        return id;
    }

    //Modification du nom du User
    public void setNomUser(String nom){
        this.nom = nom;
    }

    //Modification du prénom du User
    public void setPrenomUser(String prenom){
        this.prenom = prenom;
    }

    //Modification du login du User
    public void setLoginUser(String login){
        this.login = login;
    }

    //Modification du mot de passe du User
    public void setMdpUser(String mdp){
        this.mdp = mdp;
    }



    //Modification de l'id du User
    public void setIdUser(int id) {
        this.id = id;
    }

    //Obtenir le nom du User
    public String getNomUser(){
        return nom;
    }

    //Obtenir le prénom du User
    public String getPrenomUser(){
        return prenom;
    }

    //Obtenir le login du User
    public String getLoginUser(){
        return login;
    }

    //Obtenir le mot de passe du User
    public String getMdpUser(){
        return mdp;
    }

    public static User connection(String login, String mdp){
        return UserDAO.authenticateUser(login, mdp);
    }

    public static Client inscription(String nom, String prenom, String login, String mdp, String type){
        Client newClient = new Client(0, nom, prenom, login, mdp, new ArrayList<Reservation>(), type, 0f);
        int newId = UserDAO.createUser(newClient);
        newClient.setIdUser(newId);
        return newClient;
    }
}
