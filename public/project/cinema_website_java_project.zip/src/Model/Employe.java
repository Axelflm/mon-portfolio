package Model;

import DAO.CinemaDAO;
import DAO.FilmDAO;
import DAO.SeanceDAO;
import DAO.UserDAO;

import java.util.ArrayList;

public class Employe extends User{

    public Employe(){
        super();
    }

    public Employe(int id, String nom, String prenom, String login, String mdp){
        super(id, nom, prenom, login, mdp);
    }


    public void ajouterFilm(ArrayList<Film> catalogue, String image, String titre, String realisateur, String duree, float prix){
        Film film = new Film(image, titre, realisateur, duree, prix);
        int newId = FilmDAO.createFilm(film);
        film.setID(newId);
        catalogue.add(film);
    }

    public void modifierFilm(Film film, String image, String titre, String realisateur, String duree, float prix){
        film.setFilm(image, titre, realisateur, duree, prix);
        FilmDAO.updateFilm(film);
    }

    public void supprFilm(Cinema cinema, Film film){
        ArrayList<Seance> tmpSeances = new ArrayList<>(cinema.getAllSeances());
        for (Seance seance : tmpSeances){
            if (seance.getFilm().equals(film)){
                supprSeance(cinema.getAllSeances(), seance);
            }
        }
        FilmDAO.deleteFilm(film.getId());
        cinema.getCatalogue().remove(film);
    }

    public void ajouterSeance(ArrayList<Seance> seances, Film film, String salle, int nbplace, String date, String horaire){
        Seance seance = new Seance(film, salle, nbplace, date, horaire);
        int newId = SeanceDAO.createSeance(seance);
        seance.setId(newId);
        seances.add(seance);
    }

    public void modifierSeance(Seance seance, Film film, String salle, int nbplace, String date, String horaire){
        seance.setSeance(film, salle, nbplace, date, horaire);
        SeanceDAO.updateSeance(seance);
    }

    public void supprSeance(ArrayList<Seance> seances, Seance seance){
        for (Client client : Client.getAllClients(seances)){
            ArrayList<Reservation> reservations = new ArrayList<>(client.getReservations());
            for (Reservation reservation : reservations){
                if (reservation.getSeance().equals(seance)){
                    client.supprReservation(reservation);
                }
            }
        }
        SeanceDAO.deleteSeance(seance.getId());
        seances.remove(seance);
    }

    public void modifierReductions(Reductions reductions, float reducEnfants, float reducRegulier, float reducSenior){
        reductions.setReductions(reducEnfants, reducRegulier, reducSenior);
        CinemaDAO.updateReduction(reductions);
    }

    public void modifierReductionPerso(Client client, float newReducPerso){
        client.setReducMembre(newReducPerso);
        UserDAO.updateUser(client);
    }
}
