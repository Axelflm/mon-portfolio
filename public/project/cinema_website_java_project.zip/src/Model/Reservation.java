package Model;

import DAO.ReservationDAO;

import java.util.ArrayList;

public class Reservation {
    private int id;
    private Seance seance;
    private Client client;
    private int nbBillets;
    private float totalPaiement;

    //Constructeur d'un film sans id
    public Reservation(Seance seance, Client client, int nbBillets, float totalPaiement){
        this.id = 0; //id = 0 => pas encore créer dans la base de donnée
        this.seance = seance;
        this.client = client;
        this.nbBillets = nbBillets;
        this.totalPaiement = totalPaiement;
    }

    //Constructeur d'un film avec id
    public Reservation(int id, Seance seance, Client client, int nbBillets, float totalPaiement){
        this.id = id;
        this.seance = seance;
        this.client = client;
        this.nbBillets = nbBillets;
        this.totalPaiement = totalPaiement;
    }

    public void setId(int id){
        this.id = id;
    }

    public void setReservation(Seance seance, Client client, int nbBillets, float totalPaiement){
        this.seance = seance;
        this.client = client;
        this.nbBillets = nbBillets;
        this.totalPaiement = totalPaiement;
    }


    // Getter pour la variable 'id'
    public int getId(){
        return id;
    }

    public Seance getSeance() {
        return seance;
    }

    // Getter pour la variable 'client'
    public Client getClient() {
        return client;
    }

    // Getter pour la variable 'nbBillets'
    public int getNbBillets() {
        return nbBillets;
    }

    // Getter pour la variable 'totalPaiement'
    public float getTotalPaiement() {
        return totalPaiement;
    }

    public static ArrayList<Reservation> getAllReservations(ArrayList<Seance> seances){
        return ReservationDAO.getAllReservations(seances);
    }
}
