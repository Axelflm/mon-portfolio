package Model;

public class Seance implements Comparable<Seance>{
    private int id;
    private Film film;
    private String salle;
    private  int nbplace;
    private String date;
    private String horaire;

    //Constructeur d'une séance
    public Seance(Film film, String salle, int nbplace, String date, String horaire){
        this.id = 0; //id = 0 => pas encore créer dans la base de donnée
        this.film = film;
        this.salle = salle;
        this.nbplace = nbplace;
        this.date = date;
        this.horaire = horaire;
    }

    //Constructeur d'une séance
    public Seance(int id, Film film, String salle, int nbplace, String date, String horaire){
        this.id = id;
        this.film = film;
        this.salle = salle;
        this.nbplace = nbplace;
        this.date = date;
        this.horaire = horaire;
    }

    //Modification de l'id de la séance
    public void setId(int id) {
        this.id = id;
    }

    //Modification des attributs de la séance
    public void setSeance(Film film, String salle, int nbplace, String date, String horaire){
        this.film = film;
        this.salle = salle;
        this.nbplace = nbplace;
        this.date = date;
        this.horaire = horaire;
    }

    //Obtenir l'id de la séance
    public int getId() {
        return this.id;
    }

    //Obtenir le film de la séance
    public Film getFilm() {
        return this.film;
    }

    //Obtenir la salle de la séance
    public String getSalle() {
        return this.salle;
    }

    //Obtenir le nombre de place disponible de la séance
    public int getNbplace() {
        return this.nbplace;
    }

    //Obtenir la date de la séance
    public String getDate() {
        return this.date;
    }

    //Obtenir l'heure de début de la séance
    public String getHoraire() {
        return this.horaire;
    }

    @Override
    public int compareTo(Seance seance) {
        return this.film.getTitre().compareTo(seance.getFilm().getTitre());
    }
}
