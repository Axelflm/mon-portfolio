package Controller;

import Model.Client;
import Model.User;

import java.util.ArrayList;

public class UserController {
    private MainController mainCtrl;

    public UserController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public User getUser(){
        return mainCtrl.user;
    }

    public ArrayList<Client> getAllClients(){
        return Client.getAllClients(mainCtrl.cinema.getAllSeances());
    }

    public boolean connection(String login, String mdp){
        if (!login.isEmpty() && !mdp.isEmpty()){
            mainCtrl.user = User.connection(login, mdp);
            if (mainCtrl.user != null) {
                if (mainCtrl.user instanceof Client)
                    ((Client) mainCtrl.user).autoSetReservationsMembre(mainCtrl.cinema.getAllSeances());
                if (mainCtrl.mainView != null)
                    mainCtrl.mainView.initMenu(mainCtrl.mainView);
                return true;
            }
        }
        return false;
    }

    public void inscription(String nom, String prenom, String login, String mdp, String type){
        mainCtrl.user = User.inscription(nom, prenom, login, mdp, type);
        if(mainCtrl.mainView!=null)
            mainCtrl.mainView.initMenu(mainCtrl.mainView);
    }

    public void deconnexion(){
        mainCtrl.user = new Client();
        if(mainCtrl.mainView!=null)
            mainCtrl.mainView.initMenu(mainCtrl.mainView);
    }
}
