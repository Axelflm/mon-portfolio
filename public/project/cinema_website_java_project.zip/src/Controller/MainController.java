package Controller;

import Model.*;
import View.MainView;

public class MainController {
    protected Cinema cinema;
    protected User user;
    protected MainView mainView;
    public FilmController filmCtrl;
    public SeanceController seanceCtrl;
    public OtherController otherCtrl;
    public UserController userCtrl;
    public ReservationController reservationCtrl;
    public ReportController reportCtrl;

    public MainController() {
        initSubController();
        this.cinema = new Cinema();
        this.user = new Client();
        this.mainView = new MainView(this);
    }

    private void initSubController() {
        this.filmCtrl = new FilmController(this);
        this.seanceCtrl = new SeanceController(this);
        this.otherCtrl = new OtherController(this);
        this.userCtrl = new UserController(this);
        this.reservationCtrl = new ReservationController(this);
        this.reportCtrl = new ReportController(this);
    }
}
