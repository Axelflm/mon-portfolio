package Controller;

import Model.Client;
import Model.Film;
import Model.Reservation;
import Model.Seance;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import java.util.ArrayList;

public class ReportController {
    private MainController mainCtrl;

    public ReportController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public DefaultPieDataset createTypeClientDataset(){
        int nbEnfants = 0, nbReguliers = 0, nbSeniors = 0, nbInvites = 0;
        ArrayList<Client> clients = Client.getAllClients(mainCtrl.cinema.getAllSeances());

        for(Client client : clients){
            switch (client.getTypeMembre()){
                case "enfant":
                    nbEnfants++;
                    break;
                case "régulier":
                    nbReguliers++;
                    break;
                case "sénior":
                    nbSeniors++;
                    break;
                case "invité":
                    nbInvites++;
                    break;
                default:
                    break;
            }
        }

        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Enfants", nbEnfants);
        dataset.setValue("Réguliers", nbReguliers);
        dataset.setValue("Séniors", nbSeniors);
        dataset.setValue("Invité", nbInvites);
        return dataset;
    }

    public DefaultCategoryDataset createRevenusFilmsDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        ArrayList<Film> catalogue = mainCtrl.cinema.getCatalogue();
        for(Film film : catalogue){
            ArrayList<Seance> seances = mainCtrl.cinema.getSeances(film);
            for(Seance seance : seances){
                ArrayList<Reservation> reservations = Reservation.getAllReservations(mainCtrl.cinema.getAllSeances());
                float total = 0;
                for(Reservation reservation : reservations){
                    if(reservation.getSeance().equals(seance)){
                        total += reservation.getTotalPaiement();
                    }
                }

                // raccourcir le titre si il es trop long
                String titre = film.getTitre();
                int maxLength = 25;
                String[] words = titre.split("\\s+");
                StringBuilder sbtitre = new StringBuilder();
                for (String word : words) {
                    if (sbtitre.length() + word.length() <= maxLength)
                        sbtitre.append(word).append(" ");
                    else {
                        sbtitre.append("...");
                        break;
                    }
                }
                dataset.addValue(total, seance.getDate(), sbtitre);
            }
        }

        return dataset;
    }

    public DefaultCategoryDataset createBilletsTypeClientDataset() {
        int nbBilletsEnfants = 0, nbBilletsReguliers = 0, nbBilletsSeniors = 0, nbBilletsInvites = 0;
        ArrayList<Client> clients = Client.getAllClients(mainCtrl.cinema.getAllSeances());
        for(Client client : clients){
            int total = 0;
            for (Reservation reservation : client.getReservations()){
                total += reservation.getNbBillets();
            }
            switch (client.getTypeMembre()){
                case "enfant":
                    nbBilletsEnfants += total;
                    break;
                case "régulier":
                    nbBilletsReguliers += total;
                    break;
                case "sénior":
                    nbBilletsSeniors += total;
                    break;
                case "invité":
                    nbBilletsInvites += total;
                    break;
                default:
                    break;
            }
        }

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(nbBilletsEnfants, "Groupe 1", "Enfants");
        dataset.addValue(nbBilletsReguliers, "Groupe 1", "Réguliers");
        dataset.addValue(nbBilletsSeniors, "Groupe 1", "Séniors");
        dataset.addValue(nbBilletsInvites, "Groupe 1", "Invité");
        return dataset;
    }
}
