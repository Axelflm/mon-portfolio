package Controller;

import Model.Employe;
import Model.Film;
import Model.Seance;
import View.ViewEmpSeances;

import java.util.ArrayList;

public class SeanceController {
    private MainController mainCtrl;

    public SeanceController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public ArrayList<Seance> getAllSeances(){
        return mainCtrl.cinema.getAllSeances();
    }

    public ArrayList<Seance> getSeances(Film film){
        return mainCtrl.cinema.getSeances(film);
    }

    public void modifierSeance(Seance seance, Film film, String salle, int nbplace, String date, String horaire){
        if(mainCtrl.user instanceof Employe) {
            ((Employe) mainCtrl.user).modifierSeance(seance, film, salle, nbplace, date, horaire);
            mainCtrl.mainView.changePage(new ViewEmpSeances(mainCtrl.mainView));
        }
    }

    public void ajouterSeance(Film film, String salle, int nbplace, String date, String horaire){
        if(mainCtrl.user instanceof Employe) {
            ((Employe) mainCtrl.user).ajouterSeance(mainCtrl.cinema.getAllSeances(), film, salle, nbplace, date, horaire);
            mainCtrl.mainView.changePage(new ViewEmpSeances(mainCtrl.mainView));
        }
    }

    public void supprSeance(Seance seance){
        if(mainCtrl.user instanceof Employe) {
            ((Employe) mainCtrl.user).supprSeance(mainCtrl.cinema.getAllSeances(), seance);
        }
    }
}
