package Controller;

import Model.Client;
import Model.Employe;
import Model.Reductions;

public class OtherController {
    private MainController mainCtrl;

    public OtherController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public Reductions getReductions(){
        return mainCtrl.cinema.getAllReduc();
    }

    public void modifierReductions(float reducEnfants, float reducRegulier, float reducSenior){
        if(mainCtrl.user instanceof Employe){
            ((Employe) mainCtrl.user).modifierReductions(getReductions(), reducEnfants, reducRegulier, reducSenior);
        }
    }

    public void modifierReductionPerso(Client client, float newReducPerso){
        if(mainCtrl.user instanceof Employe){
            ((Employe) mainCtrl.user).modifierReductionPerso(client, newReducPerso);
        }
    }
}
