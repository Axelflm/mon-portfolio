package Controller;

import DAO.ReservationDAO;
import Model.Client;
import Model.Reservation;
import Model.Seance;
import View.ViewAccount;
import View.ViewAccueil;

import java.util.ArrayList;

public class ReservationController {
    private MainController mainCtrl;

    public ReservationController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public float calcPrixTot(Seance seance, int nbBillets){
        float prixTotalHorsReduction = nbBillets * seance.getFilm().getPrix();
        float Reduc = 0;
        if (mainCtrl.user instanceof Client) {
            Reduc += mainCtrl.cinema.getAllReduc().getReduc(
                    ((Client) mainCtrl.user).getTypeMembre()
            );
            Reduc += ((Client) mainCtrl.user).getReducMembre();
        }
        return Math.round(prixTotalHorsReduction * (1 - Reduc) * 100.0f) / 100.0f;
    }

    public String getReducString(){
        String reduc = "<html>";
        if (mainCtrl.user instanceof Client) {
            if(mainCtrl.user.getIdUser()!=0) {
                String type = ((Client) mainCtrl.user).getTypeMembre();
                reduc += "Membre " + type + " :  -" + mainCtrl.cinema.getAllReduc().getReduc(type)*100 + "%<br>";
            }
            if(((Client) mainCtrl.user).getReducMembre()!=0) {
                reduc += "Réduction pour vous :  -" + ((Client) mainCtrl.user).getReducMembre()*100 + "%";
            }
        }
        reduc += "</html>";
        return reduc;
    }

    public boolean reserverSeance(Seance seance, int nbBillets, String nom, String prenom){
        if (mainCtrl.user instanceof Client) {
            if(mainCtrl.user.getIdUser()==0)
                mainCtrl.userCtrl.inscription(nom, prenom, "", "", "invité");

            ((Client) mainCtrl.user).reserver(seance, ((Client) mainCtrl.user), nbBillets, calcPrixTot(seance, nbBillets));
            mainCtrl.mainView.changePage(new ViewAccount(mainCtrl.mainView, null));
            return true;

        } else
            System.out.println("Erreur : l'utilisateur n'est pas un client");
        return false;
    }

    public void supprReservation(Reservation reservation){
        if(mainCtrl.user instanceof Client) {
            ((Client) mainCtrl.user).supprReservation(reservation);
        }
    }
}
