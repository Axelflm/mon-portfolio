package Controller;

import Model.Employe;
import Model.Film;
import View.ViewCatalogue;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class FilmController {
    private MainController mainCtrl;

    public FilmController(MainController mainController){
        this.mainCtrl = mainController;
    }

    public ArrayList<Film> getCatalogue(){
        return mainCtrl.cinema.getCatalogue();
    }

    public void modifierFilm(Film film, File selectedImageFile, String titre, String realisateur, String duree, float prix){
        if(mainCtrl.user instanceof Employe) {
            try {
                uploadImage(selectedImageFile);
                ((Employe) mainCtrl.user).modifierFilm(film, "img/" + selectedImageFile.getName(), titre, realisateur, duree, prix);
                mainCtrl.mainView.changePage(new ViewCatalogue(mainCtrl.mainView));
            } catch (IOException ex) {
                System.out.println("Erreur de téléchargement de l'image : " + ex.getMessage());
            }
        }
    }

    public void ajouterFilm(File selectedImageFile, String titre, String realisateur, String duree, float prix){
        if(mainCtrl.user instanceof Employe) {
            try {
                uploadImage(selectedImageFile);
                ((Employe) mainCtrl.user).ajouterFilm(mainCtrl.cinema.getCatalogue(), "img/" + selectedImageFile.getName(), titre, realisateur, duree, prix);
                mainCtrl.mainView.changePage(new ViewCatalogue(mainCtrl.mainView));
            } catch (IOException ex) {
                System.out.println("Erreur de téléchargement de l'image : " + ex.getMessage());
            }
        }
    }

    public void supprFilm(Film film){
        if(mainCtrl.user instanceof Employe) {
            File selectedImageFile = new File(film.getImage());

            if (selectedImageFile.exists())
                selectedImageFile.delete();

            ((Employe) mainCtrl.user).supprFilm(mainCtrl.cinema, film);
        }
    }

    private void uploadImage(File selectedImageFile) throws IOException{
        // Lecture de l'image depuis le fichier source
        BufferedImage originalImage = ImageIO.read(selectedImageFile);

        // Redimensionnement de l'image
        BufferedImage resizedImage = new BufferedImage(120, 150, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = resizedImage.createGraphics();
        g2.drawImage(originalImage, 0, 0, 120, 150, null);
        g2.dispose();

        // Enregistrement de l'image redimensionnée dans le fichier de destination
        ImageIO.write(resizedImage, "jpg", new File("img/" + selectedImageFile.getName()));

    }
}
