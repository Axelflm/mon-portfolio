package View;

import Model.Film;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewAccueil extends JPanel {
    private ArrayList<Film> catalogue;

    public ViewAccueil(MainView mainView) {
        this.catalogue = mainView.getMainCtrl().filmCtrl.getCatalogue();

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 50 pixels en haut de la fenêtre
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Liste des films à l'affiche", SwingConstants.CENTER);       // Définir la taille du texte à 20
        text.setFont(new Font("SansSerif", Font.PLAIN, 25));
        p.add(text, BorderLayout.NORTH);            // Ajouter le titre au panel

        int imageHeight = 0;

        //----------------------------------------------------------------------------------------------------------------------------------
        // Création du panneau qui contiendra les informations sur les films
        JPanel panel = new JPanel(new GridLayout(catalogue.size(), 5, 0, 3)); // 5 colonnes pour image, titre, réalisateur, durée, bouton

        // Parcours des données pour chaque film
        for (Film film : catalogue) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon(film.getImage()));   // Label affiche image du film
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Titre</b><br>" + film.getTitre() + "</html>";
            JLabel titleLabel = new JLabel(texthtml);                   // Label affiche titre du film

            texthtml = "<html><b>Réalisateur</b><br>" + film.getRealisateur() + "</html>";
            JLabel directorLabel = new JLabel(texthtml);                // Label affiche réalisateur du film

            texthtml = "<html><b>Durée</b><br>" + film.getDuree() + "</html>";
            JLabel durationLabel = new JLabel(texthtml);                // Label affiche durée du film

            JButton reserveButton = new JButton("Réserver");       // Bouton pour réserver le film

            titleLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            directorLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            durationLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            reserveButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // Action du bouton "Réserver"
            reserveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Changement de page vers la page des séances
                    mainView.changePage(new ViewSeances(mainView, film));
                }
            });

            // Ajout des composants au panneau
            panel.add(imageLabel);
            panel.add(titleLabel);
            panel.add(directorLabel);
            panel.add(durationLabel);
            panel.add(reserveButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * catalogue.size()));

        JScrollPane scrollPane = new JScrollPane(panel); // Ajout d'une barre de défilement
        JPanel mainPanel = new JPanel(new BorderLayout());  // Créez un nouveau JPanel
        mainPanel.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        mainPanel.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
        this.add(mainPanel);                            // Ajout du panneau avec la barre de défilement
    }
}
