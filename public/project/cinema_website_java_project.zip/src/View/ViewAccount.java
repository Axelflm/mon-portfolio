package View;

import Model.Client;
import Model.Reservation;
import Model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewAccount extends JPanel {
    private Client client;

    public ViewAccount(MainView mainView, Client profilClient) {
        if (profilClient == null) {
            User user = mainView.getMainCtrl().userCtrl.getUser();
            if (user instanceof Client) {
                this.client = (Client) user;
            } else {
                mainView.changePage(new ViewEmploye(mainView));
                throw new IllegalArgumentException("Cannot create ViewAccount without a Client");
            }
        } else
            this.client = profilClient;

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton backButton = new JButton("Retour");

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text = new JLabel("Profil", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 30));
        backButton.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(backButton, BorderLayout.WEST);

        //----------------------------------------------------------------------------------------------------------------------------------
        // Crée un JPanel avec un BoxLayout orienté verticalement
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));


        JLabel titreCinema = new JLabel("Informations", SwingConstants.CENTER);
        titreCinema.setFont(new Font("SansSerif", Font.PLAIN, 30));


        JPanel cinemaPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        cinemaPanel.setBorder(BorderFactory.createEmptyBorder(0, 100, 10, 100));


        JLabel Nom1Label = new JLabel("Nom", SwingConstants.CENTER);
        JLabel Nom2Label = new JLabel(client.getNomUser(), SwingConstants.CENTER);
        Nom1Label.setFont(new Font("Sans", Font.BOLD, 18));
        Nom2Label.setFont(new Font("Sans", Font.PLAIN, 18));

        JLabel Prenom1Label = new JLabel("Prenom", SwingConstants.CENTER);
        JLabel Prenom2Label = new JLabel(client.getPrenomUser(), SwingConstants.CENTER);
        Prenom1Label.setFont(new Font("Sans", Font.BOLD, 18));
        Prenom2Label.setFont(new Font("Sans", Font.PLAIN, 18));

        JLabel Type1Label = new JLabel("Type", SwingConstants.CENTER);
        JLabel Type2Label = new JLabel(client.getTypeMembre(), SwingConstants.CENTER);
        Type1Label.setFont(new Font("Sans", Font.BOLD, 18));
        Type2Label.setFont(new Font("Sans", Font.PLAIN, 18));

        JLabel Reduc1Label = new JLabel("Réduction(s) Personelle(s)", SwingConstants.CENTER);
        JLabel Reduc2Label = new JLabel(Float.toString(client.getReducMembre()*100) + "%", SwingConstants.CENTER);
        Reduc1Label.setFont(new Font("Sans", Font.BOLD, 18));
        Reduc2Label.setFont(new Font("Sans", Font.PLAIN, 18));


        cinemaPanel.add(Nom1Label);     cinemaPanel.add(Nom2Label);
        cinemaPanel.add(Prenom1Label);  cinemaPanel.add(Prenom2Label);
        cinemaPanel.add(Type1Label);    cinemaPanel.add(Type2Label);
        cinemaPanel.add(Reduc1Label);   cinemaPanel.add(Reduc2Label);
        //cinemaPanel.add(new JLabel(""));

        // Titre "Mes réservations"
        JLabel ReservationTitle = new JLabel("Réservations", SwingConstants.CENTER);
        ReservationTitle.setFont(new Font("SansSerif", Font.PLAIN, 30));


        int imageHeight = 0;

        // Création du panneau qui contiendra les informations sur les films
        JPanel panel = new JPanel(new GridLayout(client.getReservations().size(), 6, 0, 3));

        // Parcours des données pour chaque film
        for (Reservation reservation : client.getReservations()) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon(reservation.getSeance().getFilm().getImage()));
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Titre</b><br>" + reservation.getSeance().getFilm().getTitre() + "</html>";
            JLabel title1Label = new JLabel(texthtml);

            texthtml = "<html><b>Date</b><br>" + reservation.getSeance().getDate() + "<br>" + reservation.getSeance().getHoraire() + "</html>";
            JLabel title2Label = new JLabel(texthtml);

            texthtml = "<html><b>Salles</b><br>" + reservation.getSeance().getSalle() + "</html>";
            JLabel title3Label = new JLabel(texthtml);

            texthtml = "<html><b>Nb de Billets</b><br>" + reservation.getNbBillets() + "</html>";
            JLabel title4Label = new JLabel(texthtml);

            JButton DeleteButton = new JButton("Annulé");

            title1Label.setFont(new Font("Sans", Font.PLAIN, 18));
            title2Label.setFont(new Font("Sans", Font.PLAIN, 18));
            title3Label.setFont(new Font("Sans", Font.PLAIN, 18));
            title4Label.setFont(new Font("Sans", Font.PLAIN, 18));
            DeleteButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // Action du bouton "supp"
            DeleteButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int option = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cette réservation ?", "Confirmation", JOptionPane.YES_NO_OPTION);

                    // Vérifiez la réponse de l'utilisateur
                    if (option == JOptionPane.YES_OPTION) {
                        mainView.getMainCtrl().reservationCtrl.supprReservation(reservation);
                        mainView.changePage(new ViewAccount(mainView, null));
                    }
                }
            });

            // Ajout des composants au panneau
            panel.add(imageLabel);
            panel.add(title1Label);
            panel.add(title2Label);
            panel.add(title3Label);
            panel.add(title4Label);
            if (profilClient==null)
                panel.add(DeleteButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * client.getReservations().size()));

        /*
        JScrollPane scrollPane = new JScrollPane(panel);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(p, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);*/


        titreCinema.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        cinemaPanel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        ReservationTitle.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        panel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement


        mainPanel.add(Box.createRigidArea(new Dimension(0, 30))); // Espacement de 30 pixels
        mainPanel.add(titreCinema);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacement de 20 pixels
        mainPanel.add(cinemaPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 50))); // Espacement de 50 pixels
        mainPanel.add(ReservationTitle);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacement de 20 pixels
        mainPanel.add(panel);
        JScrollPane scrollPane = new JScrollPane(mainPanel); // Ajout d'une barre de défilement
        this.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        this.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (mainView.getMainCtrl().userCtrl.getUser() instanceof Client)
                    mainView.changePage(new ViewAccueil(mainView));
                else
                    mainView.changePage(new ViewDossiers(mainView));
            }
        });
    }
}
