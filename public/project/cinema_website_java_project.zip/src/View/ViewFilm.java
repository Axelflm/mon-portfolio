package View;

import Model.Film;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class ViewFilm extends JPanel {
    private Film film;
    private File selectedImageFile;

    public ViewFilm(MainView mainView, Film film) {
        this.film = film; //null si nouveau film

        String imageName = null;
        String titre = null;
        String realisateur = null;
        String duree = null;
        String prix = null;
        if(film != null){
            this.selectedImageFile = new File(film.getImage());
            imageName = selectedImageFile.getName();
            titre = film.getTitre();
            realisateur = film.getRealisateur();
            duree = film.getDuree();
            prix = Float.toString(film.getPrix());
        }


        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewCatalogue(mainView));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Info du film", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);


        //----------------------------------------------------------------------------------------------------------------------------------
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        JLabel titreLabel = new JLabel("Titre:", SwingConstants.CENTER);
        JTextField titreField = new JTextField(titre);
        titreLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        titreField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(titreLabel);
        panel.add(titreField);

        JLabel realisateurLabel = new JLabel("Réalisateur:", SwingConstants.CENTER);
        JTextField realisateurField = new JTextField(realisateur);
        realisateurLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        realisateurField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(realisateurLabel);
        panel.add(realisateurField);

        JLabel dureeLabel = new JLabel("Durée:", SwingConstants.CENTER);
        JTextField dureeField = new JTextField(duree);
        dureeLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        dureeField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(dureeLabel);
        panel.add(dureeField);

        JLabel prixLabel = new JLabel("Prix:", SwingConstants.CENTER);
        JTextField prixField = new JTextField(prix);
        prixLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        prixField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(prixLabel);
        panel.add(prixField);

        JButton imageButton = new JButton("Sélectionner une image");
        imageButton.setFont(new Font("SansSerif", Font.PLAIN, 25));

        JLabel imageLabel = new JLabel(imageName);

        imageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    if (selectedImageFile != null && selectedImageFile.exists())
                        selectedImageFile.delete();
                    selectedImageFile = fileChooser.getSelectedFile();
                    imageLabel.setText(selectedImageFile.getName());
                }
            }
        });
        panel.add(imageButton);
        panel.add(imageLabel);

        JButton submitButton = new JButton("Valider");
        submitButton.setFont(new Font("SansSerif", Font.PLAIN, 25));
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String image = "img/" + selectedImageFile.getName();
                String titre = titreField.getText();
                String realisateur = realisateurField.getText();
                String duree = dureeField.getText();
                String prixText = prixField.getText();
                prixText = prixText.replace(',', '.'); // Remplacer les virgules par des points
                float prix;
                try {
                    prix = Float.parseFloat(prixText);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Format de prix invalide. Veuillez entrer un nombre décimal.", "Erreur", JOptionPane.ERROR_MESSAGE);
                    return; // Arrêter le traitement du formulaire
                }

                if (titre.isBlank() || realisateur.isBlank() || duree.isBlank() || prixText.isBlank() || selectedImageFile == null) {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs et Sélectionner une image");

                } else {
                    if(film!=null)
                        mainView.getMainCtrl().filmCtrl.modifierFilm(film, selectedImageFile, titre, realisateur, duree, prix);
                    else
                        mainView.getMainCtrl().filmCtrl.ajouterFilm(selectedImageFile, titre, realisateur, duree, prix);
                }
            }
        });

        this.add(p, BorderLayout.NORTH);
        this.add(panel, BorderLayout.CENTER);
        this.add(submitButton, BorderLayout.SOUTH);
    }

}

