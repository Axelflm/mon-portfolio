package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewEmploye extends JPanel {
    public ViewEmploye(MainView mainView) {
        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 50 pixels en haut de la fenêtre
        this.add(Box.createVerticalStrut(50), BorderLayout.NORTH);


        JPanel panel = new JPanel(new GridLayout(3, 2, 50, 50));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        JButton button1 = new JButton("Mettre à jour le catalogue");
        button1.setFont(new Font("Sans", Font.PLAIN, 20));
        JButton button2 = new JButton("Mettre à jour les séances");
        button2.setFont(new Font("Sans", Font.PLAIN, 20));
        JButton button3 = new JButton("Consulter stats des films et les commandes");
        button3.setFont(new Font("Sans", Font.PLAIN, 20));
        JButton button4 = new JButton("Consulter clients et leur commandes");
        button4.setFont(new Font("Sans", Font.PLAIN, 20));
        JButton button5 = new JButton("Introduire des réductions");
        button5.setFont(new Font("Sans", Font.PLAIN, 20));

        // Action du bouton "Catalogue"
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Changement de page vers la page des séances
                mainView.changePage(new ViewCatalogue(mainView));
            }
        });

        // Action du bouton "Séances"
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Changement de page vers la page des séances
                mainView.changePage(new ViewEmpSeances(mainView));
            }
        });

        // Action du bouton "Statistique"
        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Changement de page vers la page des séances
                mainView.changePage(new ViewReport(mainView));
            }
        });

        // Action du bouton "Dossiers Clients"
        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Changement de page vers la page des séances
                mainView.changePage(new ViewDossiers(mainView));
            }
        });

        // Action du bouton "Réductions"
        button5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Changement de page vers la page des séances
                mainView.changePage(new ViewReduction(mainView));
            }
        });

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(button4);
        panel.add(button5);
        this.add(panel, BorderLayout.CENTER);

    }
}
