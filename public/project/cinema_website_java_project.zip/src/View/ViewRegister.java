package View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewRegister extends JPanel {
    public ViewRegister(MainView mainView) {
        // Utilisation d'un GridBagLayout pour organiser les composants de manière flexible
        setLayout(new GridBagLayout());

        // Création d'un objet GridBagConstraints pour configurer les contraintes de positionnement
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espacement autour des composants

        // Création des étiquettes et des champs de texte
        JLabel nameLabel = new JLabel("Nom :");
        JTextField nameField = new JTextField(30);

        JLabel firstNameLabel = new JLabel("Prénom :");
        JTextField firstNameField = new JTextField(30);

        JLabel typeLabel = new JLabel("Type :");
        String[] types = {"régulier", "enfants", "sénior"};
        JComboBox<String> typeComboBox = new JComboBox<>(types);

        JLabel idLabel = new JLabel("Identifiant :");
        JTextField idField = new JTextField(30);

        JLabel passwordLabel = new JLabel("Mot de passe :");
        JPasswordField passwordField = new JPasswordField();


        // Configuration des dimensions des champs de texte
        Dimension fieldSize = new Dimension(400, 40);
        nameField.setPreferredSize(fieldSize);
        firstNameField.setPreferredSize(fieldSize);
        idField.setPreferredSize(fieldSize);
        passwordField.setPreferredSize(fieldSize);
        typeComboBox.setPreferredSize(fieldSize);

        // Configuration des polices pour les étiquettes et les champs de texte
        Font labelFont = new Font("SansSerif", Font.BOLD, 16);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 16);
        nameLabel.setFont(labelFont);
        firstNameLabel.setFont(labelFont);
        typeLabel.setFont(labelFont);
        idLabel.setFont(labelFont);
        passwordLabel.setFont(labelFont);

        // Configuration des polices pour les champs de texte
        nameField.setFont(fieldFont);
        firstNameField.setFont(fieldFont);
        idField.setFont(fieldFont);
        passwordField.setFont(fieldFont);
        typeComboBox.setFont(fieldFont);

        // Création de l'étiquette pour le titre
        JLabel titleLabel = new JLabel("Inscription");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24)); // Police en gras et taille 24

        // Positionnement des étiquettes et des champs de texte avec GridBagConstraints
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER; add(titleLabel, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.WEST; add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; add(nameField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; add(firstNameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; add(firstNameField, gbc);
        gbc.gridx = 0; gbc.gridy = 4; add(typeLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 4; add(typeComboBox, gbc);
        gbc.gridx = 0; gbc.gridy = 5; add(idLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 5; add(idField, gbc);
        gbc.gridx = 0; gbc.gridy = 6; add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 6; add(passwordField, gbc);

        // Création des boutons
        JButton loginButton = new JButton("Se connecter");
        JButton signupButton = new JButton("S'inscrire");
        JButton backButton = new JButton("Retour");
        loginButton.setFont(new Font("Sans", Font.PLAIN, 20));
        signupButton.setFont(new Font("Sans", Font.PLAIN, 20));
        backButton.setFont(new Font("Sans", Font.PLAIN, 20));

        // Ajout des boutons à un panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.add(signupButton);
        buttonsPanel.add(loginButton);

        // Action du bouton "Se connecter"
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewLogin(mainView));
            }
        });

        // Action du bouton "S'inscrire"
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedType = (String) typeComboBox.getSelectedItem();

                if (nameField.getText().isBlank() || firstNameField.getText().isBlank()
                        || idField.getText().isBlank() || (new String(passwordField.getPassword())).isBlank()) {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");
                } else {
                    mainView.getMainCtrl().userCtrl.inscription(nameField.getText(), firstNameField.getText(), idField.getText(), new String(passwordField.getPassword()), selectedType);
                    mainView.changePage(new ViewAccueil(mainView));
                    JOptionPane.showMessageDialog(null, "Votre compte a été créer");
                }
            }
        });

        // Action du bouton "Retour"
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewAccueil(mainView));
            }
        });

        // Ajout du panel de boutons au panel principal
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2; // Span sur deux colonnes
        gbc.anchor = GridBagConstraints.CENTER; // Alignement au centre
        add(buttonsPanel, gbc);

        // Ajout du bouton de retour au nord du panel principal
        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST; // Alignement en haut à gauche
        add(backButtonPanel, gbc);
    }

    // Autres méthodes de la classe
}
