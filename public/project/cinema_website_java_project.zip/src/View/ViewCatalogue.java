package View;

import Model.Film;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewCatalogue extends JPanel {
    private ArrayList<Film> catalogue;

    public ViewCatalogue(MainView mainView) {
        this.catalogue = mainView.getMainCtrl().filmCtrl.getCatalogue();

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmploye(mainView));
            }
        });

        JButton ajouterButton = new JButton("Ajouter");

        //Action du bouton Ajouter
        ajouterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewFilm(mainView, null));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Liste des films à l'affiche", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        ajouterButton.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);
        p.add(ajouterButton, BorderLayout.EAST);


        int imageHeight = 0;

        //----------------------------------------------------------------------------------------------------------------------------------
        // Création du panneau qui contiendra les informations sur les films
        JPanel panel = new JPanel(new GridLayout(catalogue.size(), 6, 0, 3));

        // Parcours des données pour chaque film
        for (Film film : catalogue) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon(film.getImage()));   // Label affiche image du film
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Titre</b><br>" + film.getTitre() + "</html>";
            JLabel titleLabel = new JLabel(texthtml);                   // Label affiche titre du film

            texthtml = "<html><b>Réalisateur</b><br>" + film.getRealisateur() + "</html>";
            JLabel directorLabel = new JLabel(texthtml);                // Label affiche réalisateur du film

            texthtml = "<html><b>Durée</b><br>" + film.getDuree() + "</html>";
            JLabel durationLabel = new JLabel(texthtml);                // Label affiche durée du film

            JButton modifierButton = new JButton("Modifier");       // Bouton pour Modifier le film
            JButton supprimerButton = new JButton("Supprimer");       // Bouton pour Supprimer le film

            titleLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            directorLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            durationLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            modifierButton.setFont(new Font("Sans", Font.PLAIN, 20));
            supprimerButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // Action du bouton "Modifier"
            modifierButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainView.changePage(new ViewFilm(mainView, film));
                }
            });

            // Action du bouton "Supprimer"
            supprimerButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int option = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer ce film ?", "Confirmation", JOptionPane.YES_NO_OPTION);

                    // Vérifiez la réponse de l'utilisateur
                    if (option == JOptionPane.YES_OPTION) {
                        mainView.getMainCtrl().filmCtrl.supprFilm(film);
                        mainView.changePage(new ViewCatalogue(mainView));
                    }
                }
            });

            // Ajout des composants au panneau
            panel.add(imageLabel);
            panel.add(titleLabel);
            panel.add(directorLabel);
            panel.add(durationLabel);
            panel.add(modifierButton);
            panel.add(supprimerButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * catalogue.size()));

        JScrollPane scrollPane = new JScrollPane(panel); // Ajout d'une barre de défilement
        this.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        this.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
    }
}
