package View;

import Model.Seance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class ViewEmpSeances extends JPanel {
    private ArrayList<Seance> seances;

    public ViewEmpSeances(MainView mainView) {
        this.seances = mainView.getMainCtrl().seanceCtrl.getAllSeances();
        Collections.sort(seances);

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmploye(mainView));
            }
        });

        JButton ajouterButton = new JButton("Ajouter");

        //Action du bouton Ajouter
        ajouterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmpSeance(mainView, null));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Liste des séances", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        ajouterButton.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);
        p.add(ajouterButton, BorderLayout.EAST);


        int imageHeight = 0;

        //----------------------------------------------------------------------------------------------------------------------------------
        // Création du panneau qui contiendra les informations sur les films
        JPanel panel = new JPanel(new GridLayout(seances.size(), 8, 0, 3)); // 5 colonnes pour image, titre, réalisateur, durée, bouton

        // Parcours des données pour chaque film
        for (Seance seance : seances) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon(seance.getFilm().getImage()));   // Label affiche image du film
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Durée</b><br>" + seance.getFilm().getTitre() + "</html>";
            JLabel titreLabel = new JLabel(texthtml);

            texthtml = "<html><b>Durée</b><br>" + seance.getFilm().getDuree() + "</html>";
            JLabel dureeLabel = new JLabel(texthtml);

            texthtml = "<html><b>Date</b><br>" + seance.getDate() + "<br>" + seance.getHoraire() + "</html>";
            JLabel dateLabel = new JLabel(texthtml);

            texthtml = "<html><b>Salle</b><br>" + seance.getSalle() + "</html>";
            JLabel salleLabel = new JLabel(texthtml);

            texthtml = "<html><b>Places restantes</b><br>" + seance.getNbplace() + "</html>";
            JLabel nbplaceLabel = new JLabel(texthtml);

            JButton modifierButton = new JButton("Modifier");       // Bouton pour Modifier le film
            JButton supprimerButton = new JButton("Supprimer");       // Bouton pour Supprimer le film

            titreLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            dureeLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            dateLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            salleLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            nbplaceLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            modifierButton.setFont(new Font("Sans", Font.PLAIN, 20));
            supprimerButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // Action du bouton "Modifier"
            modifierButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainView.changePage(new ViewEmpSeance(mainView, seance));
                }
            });

            // Action du bouton "Supprimer"
            supprimerButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int option = JOptionPane.showConfirmDialog(null, "Voulez-vous vraiment supprimer cette séance ?", "Confirmation", JOptionPane.YES_NO_OPTION);

                    // Vérifiez la réponse de l'utilisateur
                    if (option == JOptionPane.YES_OPTION) {
                        mainView.getMainCtrl().seanceCtrl.supprSeance(seance);
                        mainView.changePage(new ViewEmpSeances(mainView));
                    }
                }
            });

            // Ajout des composants au panneau
            panel.add(imageLabel);
            panel.add(titreLabel);
            panel.add(dureeLabel);
            panel.add(dateLabel);
            panel.add(salleLabel);
            panel.add(nbplaceLabel);
            panel.add(modifierButton);
            panel.add(supprimerButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * seances.size()));

        JScrollPane scrollPane = new JScrollPane(panel); // Ajout d'une barre de défilement
        JPanel mainPanel = new JPanel(new BorderLayout());  // Créez un nouveau JPanel
        mainPanel.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        mainPanel.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
        this.add(mainPanel);                            // Ajout du panneau avec la barre de défilement
    }
}
