package View;

import Model.Client;
import Model.Employe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewLogin extends JPanel {
    public ViewLogin(MainView mainView) {
        // Utilisation d'un GridBagLayout pour organiser les composants de manière flexible
        setLayout(new GridBagLayout());

        // Création d'un objet GridBagConstraints pour configurer les contraintes de positionnement
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espacement autour des composants

        // Création des étiquettes et des champs de texte
        JLabel idLabel = new JLabel("Identifiant :");
        JTextField idField = new JTextField(30);

        JLabel passwordLabel = new JLabel("Mot de passe :");
        JPasswordField passwordField = new JPasswordField();

        Dimension fieldSize = new Dimension(400, 40);
        idField.setPreferredSize(fieldSize);
        passwordField.setPreferredSize(fieldSize);

        // Configuration des polices pour les étiquettes et les champs de texte
        Font labelFont = new Font("SansSerif", Font.BOLD, 16);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 16);
        idLabel.setFont(labelFont);
        passwordLabel.setFont(labelFont);
        idField.setFont(fieldFont);
        passwordField.setFont(fieldFont);

        // Création de l'étiquette pour le titre
        JLabel titleLabel = new JLabel("Connexion");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24)); // Police en gras et taille 24

        // Positionnement des étiquettes et des champs de texte avec GridBagConstraints
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER; add(titleLabel, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.WEST; add(idLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; add(idField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; add(passwordField, gbc);

        // Création des boutons
        JButton loginButton = new JButton("Se connecter");
        JButton signupButton = new JButton("S'inscrire");
        JButton backButton = new JButton("Retour");
        loginButton.setFont(new Font("Sans", Font.PLAIN, 20));
        signupButton.setFont(new Font("Sans", Font.PLAIN, 20));
        backButton.setFont(new Font("Sans", Font.PLAIN, 20));

        // Ajout des boutons à un panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.add(loginButton);
        buttonsPanel.add(signupButton);

        // Action du bouton "Se connecter"
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (idField.getText().isBlank() || (new String(passwordField.getPassword())).isBlank()) {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");
                } else {
                    if (mainView.getMainCtrl().userCtrl.connection(idField.getText(), new String(passwordField.getPassword()))) {
                        if(mainView.getMainCtrl().userCtrl.getUser() instanceof Client)
                            mainView.changePage(new ViewAccueil(mainView));
                        else if(mainView.getMainCtrl().userCtrl.getUser() instanceof Employe)
                            mainView.changePage(new ViewEmploye(mainView));
                        JOptionPane.showMessageDialog(null, "Vous êtes connecté");
                    } else
                        JOptionPane.showMessageDialog(null, "Erreur login ou mot de passe incorrecte", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Action du bouton "S'inscrire"
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewRegister(mainView));
            }
        });

        // Action du bouton "Retour"
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewAccueil(mainView));
            }
        });

        // Ajout du panel de boutons au panel principal
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Span sur deux colonnes
        gbc.anchor = GridBagConstraints.CENTER; // Alignement au centre
        add(buttonsPanel, gbc);

        // Ajout du bouton de retour au nord du panel principal
        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST; // Alignement en haut à gauche
        add(backButtonPanel, gbc);
    }

    // Autres méthodes de la classe
}
