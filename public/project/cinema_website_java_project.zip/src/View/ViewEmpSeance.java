package View;

import Model.Film;
import Model.Seance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ViewEmpSeance extends JPanel {
    private Seance seance;

    public ViewEmpSeance(MainView mainView, Seance seance) {
        this.seance = seance;

        Film film = null;
        String salle = null;
        String nbPlace = null;
        String date = "";
        String horaire = "";
        if (seance != null){
            film = seance.getFilm();
            salle = seance.getSalle();
            nbPlace = Integer.toString(seance.getNbplace());
            date = seance.getDate();
            horaire = seance.getHoraire();
        }


        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmpSeances(mainView));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Info de la séance", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);


        //----------------------------------------------------------------------------------------------------------------------------------
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        JLabel filmLabel = new JLabel("Film:", SwingConstants.CENTER);
        JComboBox<Film> filmJComboBox = new JComboBox<>(mainView.getMainCtrl().filmCtrl.getCatalogue().toArray(new Film[0]));
        filmJComboBox.setSelectedItem(film);
        filmLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        filmJComboBox.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(filmLabel);
        panel.add(filmJComboBox);

        JLabel dateLabel = new JLabel("Date:", SwingConstants.CENTER);
        JPanel dateSelector = new JPanel(new FlowLayout());
        int year, month, day;
        try {
            // Création d'un objet SimpleDateFormat pour le format de date
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            // Conversion de la chaîne en objet Date
            Date dateFormater = dateFormat.parse(date);

            // Création d'un objet Calendar et définition de la date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateFormater);

            // Extraction du jour, mois et année à partir du calendrier
            year = calendar.get(Calendar.YEAR);
            month = calendar.get(Calendar.MONTH) + 1; // Les mois sont indexés à partir de 0, donc nous ajoutons 1
            day = calendar.get(Calendar.DAY_OF_MONTH);
        }catch (ParseException ex){
            year = 0;
            month = 0;
            day = 0;
        }
        // Création des JComboBox pour les sélecteurs de jour, mois et année
        JComboBox<Integer> dayComboBox = new JComboBox<>(getNumbers(1, 31));
        dayComboBox.setSelectedItem(day);
        JComboBox<Integer> monthComboBox = new JComboBox<>(getNumbers(1, 12));
        monthComboBox.setSelectedItem(month);
        JComboBox<Integer> yearComboBox = new JComboBox<>(getNumbers(1900, 2100));
        yearComboBox.setSelectedItem(year);
        // Ajout des JComboBox au panneau
        dateSelector.add(dayComboBox);
        dateSelector.add(new JLabel("/"));
        dateSelector.add(monthComboBox);
        dateSelector.add(new JLabel("/"));
        dateSelector.add(yearComboBox);
        dateLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        dateSelector.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(dateLabel);
        panel.add(dateSelector);

        JLabel heureLabel = new JLabel("Date:", SwingConstants.CENTER);
        JPanel heureSelector = new JPanel(new FlowLayout());
        int heure, minute;
        try {
            // Création d'un objet SimpleDateFormat pour le format de date
            SimpleDateFormat heureFormat = new SimpleDateFormat("HH:mm");
            // Conversion de la chaîne en objet Date
            Date heureFormater = heureFormat.parse(horaire);

            // Création d'un objet Calendar et définition de la date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(heureFormater);

            // Extraction du jour, mois et année à partir du calendrier
            heure = calendar.get(Calendar.HOUR_OF_DAY);
            minute = calendar.get(Calendar.MINUTE);
        }catch (ParseException ex){
            heure = 0;
            minute = 0;
        }
        // Création des JComboBox pour les sélecteurs de jour, mois et année
        JComboBox<Integer> heureComboBox = new JComboBox<>(getNumbers(0, 23));
        heureComboBox.setSelectedItem(heure);
        JComboBox<Integer> minuteComboBox = new JComboBox<>(getNumbers(0, 59));
        minuteComboBox.setSelectedItem(minute);
        // Ajout des JComboBox au panneau
        heureSelector.add(heureComboBox);
        heureSelector.add(new JLabel("h"));
        heureSelector.add(minuteComboBox);
        heureSelector.add(new JLabel("min"));
        heureLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        heureSelector.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(heureLabel);
        panel.add(heureSelector);

        JLabel salleLabel = new JLabel("Salle:", SwingConstants.CENTER);
        JTextField salleField = new JTextField(salle);
        salleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        salleField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(salleLabel);
        panel.add(salleField);

        JLabel nbPlaceLabel = new JLabel("Nombre de place:", SwingConstants.CENTER);
        JTextField nbPlaceField = new JTextField(nbPlace);
        nbPlaceLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        nbPlaceField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        panel.add(nbPlaceLabel);
        panel.add(nbPlaceField);


        JButton submitButton = new JButton("Valider");
        submitButton.setFont(new Font("SansSerif", Font.PLAIN, 25));
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                Film film = (Film) filmJComboBox.getSelectedItem();
                String date = dayComboBox.getSelectedItem().toString() + "-" + monthComboBox.getSelectedItem().toString() + "-" + yearComboBox.getSelectedItem().toString();
                String horaire = heureComboBox.getSelectedItem().toString() + ":" + minuteComboBox.getSelectedItem().toString();
                String salle = salleField.getText();
                String nbplace = nbPlaceField.getText();
                int nbplaceInt;
                try {
                    nbplaceInt = Integer.parseInt(nbplace);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Format de nombre de place invalide. Veuillez entrer un nombre entier.", "Erreur", JOptionPane.ERROR_MESSAGE);
                    return; // Arrêter le traitement du formulaire
                }

                if (film == null || date.isBlank() || horaire.isBlank() || salle.isBlank() || nbplaceInt == 0) {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");

                } else {
                    if(seance!=null)
                        mainView.getMainCtrl().seanceCtrl.modifierSeance(seance, film, salle, nbplaceInt, date, horaire);
                    else
                        mainView.getMainCtrl().seanceCtrl.ajouterSeance(film, salle, nbplaceInt, date, horaire);
                }
                System.out.println(film);
                System.out.println(date);
                System.out.println(horaire);
                System.out.println(salle);
                System.out.println(nbplaceInt);
            }
        });

        this.add(p, BorderLayout.NORTH);
        this.add(panel, BorderLayout.CENTER);
        this.add(submitButton, BorderLayout.SOUTH);
    }

    // Méthode utilitaire pour créer un tableau d'entiers
    private static Integer[] getNumbers(int start, int end) {
        Integer[] numbers = new Integer[end - start + 1];
        for (int i = start; i <= end; i++) {
            numbers[i - start] = i;
        }
        return numbers;
    }

}

