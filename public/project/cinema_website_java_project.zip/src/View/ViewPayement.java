package View;

import Model.Seance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewPayement extends JPanel {
    private Seance seance;

    public ViewPayement(MainView mainView, Seance seance) {
        this.seance = seance;

        JButton boutonR =new JButton("Retour");
        boutonR.setBounds(70,10,95,30);
        boutonR.setFont(new Font("SansSerif", Font.PLAIN, 20));
        //Action du boutonR Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewSeances(mainView, seance.getFilm()));
            }
        });

        JLabel titre = new JLabel("Séances du " + seance.getDate() + " pour le film : " + seance.getFilm().getTitre(), SwingConstants.CENTER);
        titre.setFont(new Font("SansSerif", Font.BOLD, 25)); //Grossissement du titre
        titre.setBounds(200,10, 1000,50);

        //Affichage nb Billets
        JLabel l1 = new JLabel("Nombre de billets : ");
        l1.setFont(new Font("SansSerif", Font.BOLD, 25)); //Grossissement du titre
        l1.setBounds(50,80, 300,50);

        //ComboBox pour nb Billets
        String[] nbBillet = {"1","2","3","4","5","6","7","8","9","10"};
        JComboBox billets = new JComboBox(nbBillet);
        billets.setBounds(282, 93,70,30);
        billets.setFont(new Font("SansSerif", Font.BOLD, 18));

        //Affichage Prix
        float prixTot = mainView.getMainCtrl().reservationCtrl.calcPrixTot(seance, 1);
        JLabel l2 =new JLabel("Total : " + prixTot + "€");
        l2.setFont(new Font("SansSerif", Font.BOLD, 30)); //Grossissement du titre
        l2.setBounds(800,80, 300,50);
        // Ajouter un ActionListener au JComboBox
        billets.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Action à effectuer lorsque le JComboBox change de sélection
                String bill = (String) billets.getItemAt(billets.getSelectedIndex());   //Récupération du nombre de billets
                int nbBillets = Integer.parseInt(bill); //Tranformation String -> int
                float prixTot = mainView.getMainCtrl().reservationCtrl.calcPrixTot(seance, nbBillets);
                l2.setText("Total : " + prixTot + "€"); //Affichage
            }
        });


        //Affichage Réduc applicable
        String reducAppliquer = mainView.getMainCtrl().reservationCtrl.getReducString();

        JLabel l3 =new JLabel("Réduction applicable : ");
        l3.setFont(new Font("SansSerif", Font.BOLD, 25)); //Grossissement du titre
        l3.setBounds(50,150, 300,50);

        JLabel lR =new JLabel(reducAppliquer);
        lR.setFont(new Font("SansSerif", Font.BOLD, 25)); //Grossissement du titre
        lR.setBounds(360,125, 400,100);

        //Affichage Paiement
        JLabel l4 =new JLabel("Paiement ");
        l4.setFont(new Font("SansSerif", Font.BOLD, 25)); //Grossissement du titre
        l4.setBounds(50,250, 300,50);
        JLabel l5 =new JLabel("Numéro de la carte ");
        l5.setFont(new Font("SansSerif", Font.BOLD, 20)); //Grossissement du titre
        l5.setBounds(50,295, 300,50);
        JTextField t1 =new JTextField("");
        t1.setBounds(50,335, 200,30);
        JLabel l6 =new JLabel("CVC ");
        l6.setFont(new Font("SansSerif", Font.BOLD, 20)); //Grossissement du titre
        l6.setBounds(300,295, 300,50);
        JTextField t2 =new JTextField("");
        t2.setBounds(300,335, 70,30);
        JLabel l7 =new JLabel("Date d'expiration ");
        l7.setFont(new Font("SansSerif", Font.BOLD, 20)); //Grossissement du titre
        l7.setBounds(50,365, 300,50);
        JTextField t3 =new JTextField("");
        t3.setBounds(50,408, 150,30);


        // afficher uniquement si l'utilisateur n'a pas de compte
        JLabel l8 = new JLabel("Nom ");
        l8.setFont(new Font("SansSerif", Font.BOLD, 20)); //Grossissement du titre
        l8.setBounds(420, 295, 300, 50);
        JTextField t4 = new JTextField("");
        t4.setBounds(420, 335, 200, 30);
        JLabel l9 = new JLabel("Prénom ");
        l9.setFont(new Font("SansSerif", Font.BOLD, 20)); //Grossissement du titre
        l9.setBounds(420, 365, 300, 50);
        JTextField t5 = new JTextField("");
        t5.setBounds(420, 408, 200, 30);


        //Bouton Payer
        JButton boutonC =new JButton("Payer");
        boutonC.setBounds(790,352,100,50);
        boutonC.setFont(new Font("SansSerif", Font.BOLD, 22));

        //Action du boutonM
        boutonC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (t1.getText().isBlank() || t2.getText().isBlank() || t3.getText().isBlank())
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");
                else if (mainView.getMainCtrl().userCtrl.getUser().getIdUser() == 0 && (t4.getText().isBlank() || t5.getText().isBlank())) {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");
                } else{
                    String bill = (String) billets.getItemAt(billets.getSelectedIndex());   //Récupération du nombre de billets
                    int nbBillets = Integer.parseInt(bill); //Tranformation String -> int
                    String nom = t4.getText();
                    String prenom = t5.getText();
                    if (mainView.getMainCtrl().reservationCtrl.reserverSeance(seance, nbBillets, nom, prenom))
                        JOptionPane.showMessageDialog(null, "La séance a été réservé");
                    else
                        JOptionPane.showMessageDialog(null, "Erreur :  la réservation n'a pas pu aboutir", "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


       //Insertion sur la fenêtre
        this.add(billets);
        this.add(titre);
        this.add(l1);
        this.add(l2);
        this.add(l3);
        this.add(lR);
        this.add(l4);
        this.add(l5);
        this.add(l6);
        this.add(l7);
        this.add(t1);
        this.add(t2);
        this.add(t3);
        if(mainView.getMainCtrl().userCtrl.getUser().getIdUser() == 0) {
            this.add(l8);
            this.add(t4);
            this.add(l9);
            this.add(t5);
        }

        this.add(boutonR);
        this.add(boutonC);
        this.setLayout(null);

    }
}
