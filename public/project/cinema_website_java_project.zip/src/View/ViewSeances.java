package View;

import Model.Film;
import Model.Seance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewSeances extends JPanel  {
    private Film film;
    private ArrayList<Seance> seances;

    public ViewSeances(MainView mainView, Film film) {
        this.film = film;
        this.seances = mainView.getMainCtrl().seanceCtrl.getSeances(film);

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton bouton3 =new JButton("Retour");

        //Action du bouton Retour
        bouton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewAccueil(mainView));
            }
        });
        //this.add(bouton3);

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Choix des séances pour le film : " + film.getTitre(), SwingConstants.CENTER);       // Définir la taille du texte à 20
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        bouton3.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);            // Ajouter le titre au panel
        p.add(bouton3, BorderLayout.WEST);


        int imageHeight = 0;

        //----------------------------------------------------------------------------------------------------------------------------------
        // Création du panneau qui contiendra les informations sur les séances
        JPanel panel = new JPanel(new GridLayout(seances.size(), 6, 0, 3));

        for (Seance seance : seances) {

            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon(film.getImage()));   // Label affiche image du film
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Durée</b><br>" + film.getDuree() + "</html>";
            JLabel dureeLabel = new JLabel(texthtml);

            texthtml = "<html><b>Date</b><br>" + seance.getDate() + "<br>" + seance.getHoraire() + "</html>";
            JLabel horaireLabel = new JLabel(texthtml);

            texthtml = "<html><b>Salle</b><br>" + seance.getSalle() + "</html>";
            JLabel salleLabel = new JLabel(texthtml);

            texthtml = "<html><b>Places restantes</b><br>" + seance.getNbplace() + "</html>";
            JLabel placeLabel = new JLabel(texthtml);

            JButton reserveButton = new JButton("<html><center>Choisir cette<br>séance</center></html>");       // Bouton pour réserver le film

            dureeLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            horaireLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            salleLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            placeLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            reserveButton.setFont(new Font("Sans", Font.PLAIN, 20));

            reserveButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainView.changePage(new ViewPayement(mainView, seance));
                }
            });

            panel.add(imageLabel);
            panel.add(dureeLabel);
            panel.add(horaireLabel);
            panel.add(salleLabel);
            panel.add(placeLabel);
            panel.add(reserveButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * seances.size()));

        JScrollPane scrollPane = new JScrollPane(panel);
        JPanel mainPanel = new JPanel(new BorderLayout());  // Créez un nouveau JPanel
        mainPanel.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        mainPanel.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
        this.add(mainPanel);                                // Ajoutez mainPanel à la JFrame
    }
}
