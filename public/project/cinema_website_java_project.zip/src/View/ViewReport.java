package View;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ViewReport extends JPanel {
    public ViewReport(MainView mainView) {
        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmploye(mainView));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Statistiques", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);


        //----------------------------------------------------------------------------------------------------------------------------------
        // Créer un jeu de données pour le camembert
        DefaultPieDataset dataset1 = mainView.getMainCtrl().reportCtrl.createTypeClientDataset();

        // Créer le camembert à partir du jeu de données
        JFreeChart chart1 = ChartFactory.createPieChart(
                "Type des Clients",  // Titre du graphique
                dataset1,                  // Jeu de données
                true,                     // Afficher la légende
                true,                     // Activer l'outil de notation
                false                     // Activer les liens URL
        );

        // Créer un panneau de graphique pour afficher le graphique
        ChartPanel chartPanel1 = new ChartPanel(chart1);



        //----------------------------------------------------------------------------------------------------------------------------------
        // Créer un jeu de données pour le camembert
        DefaultCategoryDataset dataset2 = mainView.getMainCtrl().reportCtrl.createBilletsTypeClientDataset();

        // Créer le camembert à partir du jeu de données
        JFreeChart chart2 = ChartFactory.createStackedBarChart(
                "Billets vendus par type de Clients",// Titre du graphique
                "Type du client",                         // Axe des X
                "Nombre de billets vendus",               // Axe des Y
                dataset2                                  // Jeu de données
        );

        chart2.getLegend().setVisible(false);

        // Créer un panneau de graphique pour afficher le graphique
        ChartPanel chartPanel2 = new ChartPanel(chart2);



        //----------------------------------------------------------------------------------------------------------------------------------
        // Créer un jeu de données pour le camembert
        DefaultCategoryDataset dataset3 = mainView.getMainCtrl().reportCtrl.createRevenusFilmsDataset();

        // Créer le camembert à partir du jeu de données
        JFreeChart chart3 = ChartFactory.createStackedBarChart(
                "Revenus des films",                 // Titre du graphique
                "Films",                                  // Axe des X
                "Revenus Totaux",                         // Axe des Y
                dataset3                                  // Jeu de données
        );

        // Faire pivoter les titres des catégories à un angle de 45 degrés
        CategoryPlot plot3 = (CategoryPlot) chart3.getPlot();
        plot3.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        plot3.getDomainAxis().setMaximumCategoryLabelWidthRatio(0.6f);

        // Créer un panneau de graphique pour afficher le graphique
        ChartPanel chartPanel3 = new ChartPanel(chart3);


        // Créer le conteneur pour les panneaux de graphique
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Ajouter le premier diagramme en haut à gauche
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(20, 20, 20, 20); // Ajouter un espace de 10 pixels entre les éléments
        panel.add(chartPanel1, gbc);

        // Ajouter le deuxième diagramme en haut à droite
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(chartPanel2, gbc);

        // Fusionner les deux cellules du bas
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        panel.add(chartPanel3, gbc);


        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, mainView.getFenetre().getHeight() * 2));
        JScrollPane scrollPane = new JScrollPane(panel);

        this.add(p, BorderLayout.NORTH);
        this.add(scrollPane, BorderLayout.CENTER);
    }
}
