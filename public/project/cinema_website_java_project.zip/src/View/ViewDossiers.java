package View;

import Model.Client;
import Model.Film;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewDossiers extends JPanel {
    private ArrayList<Client> clients;

    public ViewDossiers(MainView mainView) {
        this.clients = mainView.getMainCtrl().userCtrl.getAllClients();

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmploye(mainView));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text = new JLabel("Liste des films à l'affiche", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 20));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);


        int imageHeight = 0;

        //----------------------------------------------------------------------------------------------------------------------------------
        // Création du panneau qui contiendra les informations sur les films
        JPanel panel = new JPanel(new GridLayout(clients.size(), 6, 0, 3));

        // Parcours des données pour chaques clients
        for (Client client : clients) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon("img/GuestProfile.jpg"));
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Nom</b><br>" + client.getNomUser() + "</html>";
            JLabel nomLabel = new JLabel(texthtml);

            texthtml = "<html><b>Prénom</b><br>" + client.getPrenomUser() + "</html>";
            JLabel prenomLabel = new JLabel(texthtml);

            texthtml = "<html><b>Type</b><br>" + client.getTypeMembre() + "</html>";
            JLabel typeLabel = new JLabel(texthtml);

            texthtml = "<html><b>Nombre de Réservation</b><br>" + client.getReservations().size() + "</html>";
            JLabel nbResaLabel = new JLabel(texthtml);


            JButton voirButton = new JButton("Voir");


            nomLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            prenomLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            typeLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            nbResaLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            voirButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // détection de la modification de la réduction
            voirButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainView.changePage(new ViewAccount(mainView, client));
                }
            });

            // Ajout des composants au panneau
            panel.add(imageLabel);
            panel.add(nomLabel);
            panel.add(prenomLabel);
            panel.add(typeLabel);
            panel.add(nbResaLabel);
            panel.add(voirButton);
        }

        // Définir la taille préférée du JPanel
        panel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * clients.size()));

        JScrollPane scrollPane = new JScrollPane(panel); // Ajout d'une barre de défilement
        this.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        this.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
    }
}