package View;

import Controller.MainController;
import DAO.DAOManager;
import Model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainView {
    private MainController mainCtrl;
    private JFrame fenetre;         // Fenêtre principale de l'application
    private JMenuBar mainbar;       // Barre de menu principale
    private JPanel content;          // Conteneur principal pour le contenu changeant

    public MainView(MainController mainController){
        this.mainCtrl = mainController;

        // Création de la fenêtre principale
        fenetre = new JFrame("Application");
        fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fenetre.setSize(1100, 600);             // Taille de la fenêtre
        fenetre.setLocationRelativeTo(null);                // Centrer la fenêtre sur l'écran

        // WindowListener pour détecter la fermeture de la fenêtre
        fenetre.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Action à effectuer lors de la fermeture de la fenêtre
                DAOManager.closeConnection();
                // Autres actions de nettoyage si nécessaire
                System.exit(0); // Fermeture de l'application
            }
        });

        // Création du panneau de contenu principal
        content = new JPanel(new CardLayout());
        fenetre.getContentPane().add(content);              // Ajout du panneau de contenu à la fenêtre

        // Initialisation de la barre de menu
        initMenu(this);

        // Afficher la première page (par exemple, la page d'accueil)
        changePage(new ViewAccueil(this));

        // Rendre la fenêtre visible
        fenetre.setVisible(true);
    }

    public JFrame getFenetre() {
        return fenetre;
    }

    public MainController getMainCtrl() {
        return mainCtrl;
    }

    // -------------------- Méthode pour changer la page affichée dans le contenu principal --------------------
    public void changePage(JPanel newPage){
        content.removeAll();
        content.add(newPage);
        ((CardLayout) content.getLayout()).show(content, "Page");       // Affiche la nouvelle page

        // afficher ou masquer la barre de menu
        /*if (newPage instanceof ViewEmploye) {
            fenetre.setJMenuBar(null);
        } else {
            fenetre.setJMenuBar(mainbar);
        }*/
        fenetre.setJMenuBar(mainbar);

        fenetre.revalidate();                                   // Rafraîchit la fenêtre pour refléter les changements
    }

    // -------------------- Initialisation de la barre de menu --------------------
    public void initMenu(MainView mainView){
        JMenuItem bouton1, bouton2;
        mainbar = new JMenuBar();                               // Barre de menu principale
        JMenu menu = new JMenu();                               // Menu

        // Chargement des images pour le profil et le logo du cinéma
        ImageIcon profile = new ImageIcon("img/GuestProfile.jpg");
        ImageIcon logoCine = new ImageIcon("img/ece.jpg");

        // Création d'un label pour afficher le logo
        JLabel logolabel = new JLabel();
        logolabel.setHorizontalAlignment(JLabel.RIGHT);                             // Alignement de l'image à droite

        User user = mainCtrl.userCtrl.getUser();
        JLabel titlelabel1 = new JLabel("ECE Cinemas : Exploration des 42 Mondes du Cinéma            ");   // Label pour afficher le titre du cinéma
        JLabel titlelabel2 = new JLabel("<html>"+user.getNomUser()+"<br>"+user.getPrenomUser()+"</html>");   // Label pour afficher "Mon profil"

        // Configuration de la police pour le titre
        titlelabel1.setFont(new Font("SansSerif", Font.BOLD, 25));        // Augmentation de la taille du titre
        titlelabel2.setFont(new Font("SansSerif", Font.BOLD, 25));

        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.add(titlelabel1, BorderLayout.CENTER);
        JPanel secondTextLabelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        secondTextLabelPanel.add(titlelabel2);
        titlePanel.add(secondTextLabelPanel, BorderLayout.WEST);
        titlelabel1.setHorizontalAlignment(SwingConstants.CENTER);

        // Ajout du logo au label
        logolabel.setIcon(logoCine);

        // Création des éléments du menu
        menu.setIcon(profile);
        if(user.getIdUser() == 0) { // l'utilisateur n'est pas connecté à son compte
            bouton1 = new JMenuItem("Me connecter");
            bouton2 = new JMenuItem("Créer mon compte");

            // Action du bouton "Me connecter"
            bouton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    changePage(new ViewLogin(mainView));
                }
            });

            // Action du bouton "Créer mon compte"
            bouton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    changePage(new ViewRegister(mainView));
                }
            });
        } else { // l'utilisateur est connecté à son compte
            bouton1 = new JMenuItem("Voir mon compte");
            bouton2 = new JMenuItem("Déconnexion");

            // Action du bouton "Me connecter"
            bouton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    changePage(new ViewAccount(mainView, null));
                }
            });

            // Action du bouton "Créer mon compte"
            bouton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainCtrl.userCtrl.deconnexion();
                    changePage(new ViewAccueil(mainView));
                    JOptionPane.showMessageDialog(null, "Vous êtes déconnecté");
                }
            });
        }

        // Ajout des éléments au menu
        menu.add(bouton1);
        menu.addSeparator();
        menu.add(bouton2);

        mainbar.add(menu);                              // Ajout du menu à la barre de menu principale
        mainbar.add(Box.createHorizontalGlue());        // Ajout d'espace à gauche
        mainbar.add(titlePanel);                        // Ajout du titre du cinéma
        mainbar.add(Box.createHorizontalGlue());        // Ajout d'espace à droite
        mainbar.add(logolabel);                         // Ajout du logo du cinéma à la barre de menu
    }
}
