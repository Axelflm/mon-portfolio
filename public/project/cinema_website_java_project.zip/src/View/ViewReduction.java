package View;

import Model.Client;
import Model.Reductions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ViewReduction extends JPanel {
    private ArrayList<Client> clients;
    private Reductions reductions;

    public ViewReduction(MainView mainView) {
        this.clients = mainView.getMainCtrl().userCtrl.getAllClients();
        this.reductions = mainView.getMainCtrl().otherCtrl.getReductions();

        // Utilisation d'un BorderLayout pour organiser les composants
        setLayout(new BorderLayout());

        //Ajoute un espace vertical de 10 pixels
        this.add(Box.createVerticalStrut(10), BorderLayout.NORTH);

        JButton boutonR = new JButton("Retour");

        //Action du bouton Retour
        boutonR.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainView.changePage(new ViewEmploye(mainView));
            }
        });

        //Pour centrer seulement horizontalement le texte
        JPanel p = new JPanel(new BorderLayout());
        JLabel text=new JLabel("Réductions", SwingConstants.CENTER);
        text.setFont(new Font("SansSerif", Font.PLAIN, 30));
        boutonR.setFont(new Font("Sans", Font.PLAIN, 20));
        p.add(text, BorderLayout.CENTER);
        p.add(boutonR, BorderLayout.WEST);

        //----------------------------------------------------------------------------------------------------------------------------------
        // Crée un JPanel avec un BoxLayout orienté verticalement
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));


        JLabel titreCinema = new JLabel("Réductions du Cinéma pour ses membres", SwingConstants.CENTER);
        titreCinema.setFont(new Font("SansSerif", Font.PLAIN, 30));


        JPanel cinemaPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        cinemaPanel.setBorder(BorderFactory.createEmptyBorder(0, 100, 10, 100));

        JLabel column1 = new JLabel("<html><b>Type Client</b></html", SwingConstants.CENTER);
        JLabel column2 = new JLabel("<html><b>Réduction (en %)</b></html", SwingConstants.CENTER);
        column1.setFont(new Font("Sans", Font.PLAIN, 20));
        column2.setFont(new Font("Sans", Font.PLAIN, 20));

        JLabel reducEnfantsLabel = new JLabel("Enfants", SwingConstants.CENTER);
        JTextField reducEnfantsField = new JFormattedTextField(Integer.toString(Math.round(reductions.getReducEnfants()*100)));
        reducEnfantsField.setHorizontalAlignment(SwingConstants.CENTER); // Centrer le texte
        reducEnfantsLabel.setFont(new Font("Sans", Font.PLAIN, 18));
        reducEnfantsField.setFont(new Font("Sans", Font.PLAIN, 18));

        JLabel reducRegulierLabel = new JLabel("Réguliers", SwingConstants.CENTER);
        JTextField reducRegulierField = new JFormattedTextField(Integer.toString(Math.round(reductions.getReducRegulier()*100)));
        reducRegulierField.setHorizontalAlignment(SwingConstants.CENTER); // Centrer le texte
        reducRegulierLabel.setFont(new Font("Sans", Font.PLAIN, 18));
        reducRegulierField.setFont(new Font("Sans", Font.PLAIN, 18));

        JLabel reducSeniorsLabel = new JLabel("Séniors", SwingConstants.CENTER);
        JTextField reducSeniorsField = new JFormattedTextField(Integer.toString(Math.round(reductions.getReducSenior()*100)));
        reducSeniorsField.setHorizontalAlignment(SwingConstants.CENTER); // Centrer le texte
        reducSeniorsLabel.setFont(new Font("Sans", Font.PLAIN, 18));
        reducSeniorsField.setFont(new Font("Sans", Font.PLAIN, 18));

        JButton validerReductionsButton = new JButton("Valider les Réductions");
        validerReductionsButton.setFont(new Font("Sans", Font.PLAIN, 20));
        validerReductionsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(reducEnfantsField.getText().isBlank() || reducRegulierField.getText().isBlank() || reducSeniorsField.getText().isBlank()){
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs");
                } else {
                    float reducEnfants = Float.parseFloat(reducEnfantsField.getText()) / 100f;
                    float reducRegulier = Float.parseFloat(reducRegulierField.getText()) / 100f;
                    float reducSeniors = Float.parseFloat(reducSeniorsField.getText()) / 100f;
                    mainView.getMainCtrl().otherCtrl.modifierReductions(reducEnfants, reducRegulier, reducSeniors);
                    JOptionPane.showMessageDialog(null, "Les réductions ont été sauvegarder");
                }
            }
        });

        cinemaPanel.add(column1);
        cinemaPanel.add(column2);
        cinemaPanel.add(reducEnfantsLabel);
        cinemaPanel.add(reducEnfantsField);
        cinemaPanel.add(reducRegulierLabel);
        cinemaPanel.add(reducRegulierField);
        cinemaPanel.add(reducSeniorsLabel);
        cinemaPanel.add(reducSeniorsField);
        cinemaPanel.add(new JLabel(""));
        cinemaPanel.add(validerReductionsButton);





        JLabel titreClient = new JLabel("Réductions spécial pour les clients", SwingConstants.CENTER);
        titreClient.setFont(new Font("SansSerif", Font.PLAIN, 30));


        int imageHeight = 0;

        JPanel clientsPanel = new JPanel(new GridLayout(clients.size(), 6, 0, 3));

        // Parcours des données pour chaques clients
        for (Client client : clients) {
            String texthtml;
            JLabel imageLabel = new JLabel(new ImageIcon("img/GuestProfile.jpg"));
            imageHeight = imageLabel.getPreferredSize().height;

            texthtml = "<html><b>Nom</b><br>" + client.getNomUser() + "</html>";
            JLabel nomLabel = new JLabel(texthtml);

            texthtml = "<html><b>Prénom</b><br>" + client.getPrenomUser() + "</html>";
            JLabel prenomLabel = new JLabel(texthtml);

            texthtml = "<html><b>Type</b><br>" + client.getTypeMembre() + "</html>";
            JLabel typeLabel = new JLabel(texthtml);

            JPanel reducPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JLabel reducLabel = new JLabel("<html><b>Réduction : </b></html>");
            String[] reducValue = {"0","5","10","15","20","25","30","40","50","60","70","80","90","100"};
            JComboBox<String> reducField = new JComboBox<>(reducValue);
            reducField.setSelectedItem(Integer.toString(Math.round(client.getReducMembre()*100)));
            reducPanel.add(reducLabel);
            reducPanel.add(reducField);

            JPanel buttonPanel = new JPanel(new GridLayout(2, 1));
            JButton validerButton = new JButton("Valider");
            JButton annulerButton = new JButton("Annuler");
            buttonPanel.setVisible(false);
            buttonPanel.add(validerButton);
            buttonPanel.add(annulerButton);

            nomLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            prenomLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            typeLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            reducLabel.setFont(new Font("Sans", Font.PLAIN, 18));
            reducField.setFont(new Font("Sans", Font.PLAIN, 18));
            validerButton.setFont(new Font("Sans", Font.PLAIN, 20));
            annulerButton.setFont(new Font("Sans", Font.PLAIN, 20));

            // détection de la modification de la réduction
            reducField.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                   buttonPanel.setVisible(true);
               }
            });

            // Action du bouton "Valider"
            validerButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    float newReducPerso = Integer.parseInt((String) reducField.getItemAt(reducField.getSelectedIndex())) / 100f;
                    mainView.getMainCtrl().otherCtrl.modifierReductionPerso(client, newReducPerso);
                    buttonPanel.setVisible(false);
                }
            });

            // Action du bouton "Annuler"
            annulerButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    reducField.setSelectedItem(Integer.toString(Math.round(client.getReducMembre()*100)));
                    buttonPanel.setVisible(false);
                }
            });

            // Ajout des composants au panneau
            clientsPanel.add(imageLabel);
            clientsPanel.add(nomLabel);
            clientsPanel.add(prenomLabel);
            clientsPanel.add(typeLabel);
            clientsPanel.add(reducPanel);
            clientsPanel.add(buttonPanel);
        }

        // Définir la taille préférée du JPanel
        clientsPanel.setPreferredSize(new Dimension(mainView.getFenetre().getWidth() - 30, imageHeight * clients.size()));

        titreCinema.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        cinemaPanel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        titreClient.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement
        clientsPanel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centre le composant horizontalement


        mainPanel.add(Box.createRigidArea(new Dimension(0, 30))); // Espacement de 30 pixels
        mainPanel.add(titreCinema);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacement de 20 pixels
        mainPanel.add(cinemaPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 50))); // Espacement de 50 pixels
        mainPanel.add(titreClient);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Espacement de 20 pixels
        mainPanel.add(clientsPanel);
        JScrollPane scrollPane = new JScrollPane(mainPanel); // Ajout d'une barre de défilement
        this.add(p, BorderLayout.NORTH);               // Ajoutez le texte au nord
        this.add(scrollPane, BorderLayout.CENTER);     // Ajoutez le JScrollPane au centre
    }
}
