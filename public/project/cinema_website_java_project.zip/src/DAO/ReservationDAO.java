package DAO;

import Model.Client;
import Model.Reservation;
import Model.Seance;

import java.sql.*;
import java.util.ArrayList;

public abstract class ReservationDAO {
    public static ArrayList<Reservation> getAllReservations(ArrayList<Seance> seances) {
        Connection bdd_conn = DAOManager.getConnection();
        Statement stmt = null;
        ResultSet resultSet = null;
        ArrayList<Reservation> reservations = new ArrayList<>();
        ArrayList<Client> users = UserDAO.getAllClients();
        try {
            stmt = bdd_conn.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM reservations");

            // Récupération des séances
            while (resultSet.next()) {
                int reservationID = resultSet.getInt("ReservationID");
                int clientID = resultSet.getInt("ClientID");
                int seanceID = resultSet.getInt("SeanceID");
                int nbBillets = resultSet.getInt("nbBillets");
                float TotalPaiement = resultSet.getFloat("TotalPaiement");

                // Parcours des séances pour trouver la séance recherchée
                Seance seanceReservation = null;
                for (Seance seance : seances) {
                    if (seance.getId() == seanceID) {
                        seanceReservation = seance;
                        break; // Sortie de la boucle dès que le film est trouvé
                    }
                }

                Client client = null;
                for (Client user : users) {
                    if (user.getIdUser() == clientID) {
                        client = user;
                        break; // Sortie de la boucle dès que le film est trouvé
                    }
                }

                if(seanceReservation != null) {
                    // Création d'un objet Seance et ajout à la liste
                    Reservation reservation = new Reservation(reservationID, seanceReservation, client, nbBillets, TotalPaiement);
                    reservations.add(reservation);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention des réservations: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return reservations;
    }

    public static ArrayList<Reservation> getReservationsClient(ArrayList<Seance> seances, Client client) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        ResultSet resultSet = null;
        ArrayList<Reservation> reservations = new ArrayList<>();
        try {
            String query = "SELECT * FROM reservations WHERE ClientID = ?";
            pstmt = bdd_conn.prepareStatement(query);
            pstmt.setInt(1, client.getIdUser());
            resultSet = pstmt.executeQuery();


            // Récupération des séances
            while (resultSet.next()) {
                int reservationID = resultSet.getInt("ReservationID");
                int clientID = resultSet.getInt("ClientID");
                int seanceID = resultSet.getInt("SeanceID");
                int nbBillets = resultSet.getInt("nbBillets");
                float TotalPaiement = resultSet.getFloat("TotalPaiement");

                // Parcours des séances pour trouver la séance recherchée
                Seance seanceReservation = null;
                for (Seance seance : seances) {
                    if (seance.getId() == seanceID) {
                        seanceReservation = seance;
                        break; // Sortie de la boucle dès que le film est trouvé
                    }
                }

                if(seanceReservation != null) {
                    // Création d'un objet Seance et ajout à la liste
                    Reservation reservation = new Reservation(reservationID, seanceReservation, client, nbBillets, TotalPaiement);
                    reservations.add(reservation);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention des réservation du client: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return reservations;
    }


    public static void updateReservation(Reservation reservation) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE Reservations SET ClientID = ?, SeanceID = ?, NbBillets = ?, TotalPaiement = ? WHERE ReservationID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setInt(1, reservation.getClient().getIdUser());
            pstmt.setInt(2, reservation.getSeance().getId());
            pstmt.setInt(3, reservation.getNbBillets());
            pstmt.setFloat(4, reservation.getTotalPaiement());
            pstmt.setInt(5, reservation.getId());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de la réservation: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static int createReservation(Reservation reservation) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        int newReservationID = 0;
        try {
            // Préparation de la requête SQL d'insertion
            String query = "INSERT INTO Reservations (ClientID, SeanceID, NbBillets, TotalPaiement) VALUES (?, ?, ?, ?)";
            pstmt = bdd_conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setInt(1, reservation.getClient().getIdUser());
            pstmt.setInt(2, reservation.getSeance().getId());
            pstmt.setInt(3, reservation.getNbBillets());
            pstmt.setFloat(4, reservation.getTotalPaiement());

            // Exécution de la requête
            pstmt.executeUpdate();

            // Récupération de l'ID de la nouvelle séance insérée
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                newReservationID = generatedKeys.getInt(1);
            } else {
                throw new SQLException("la récupération de l'ID généré pour la séance.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création de la réservation: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return newReservationID;
    }


    public static void deleteReservation(int reservationID) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL de suppression
            String query = "DELETE FROM reservations WHERE ReservationID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation de la valeur du paramètre de la requête
            pstmt.setInt(1, reservationID);

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de la réservation: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }


}
