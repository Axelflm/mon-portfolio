package DAO;

import Model.Film;
import Model.Seance;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public abstract class SeanceDAO {
    public static ArrayList<Seance> getAllSeances(ArrayList<Film> catalogue) {
        Connection bdd_conn = DAOManager.getConnection();
        Statement stmt = null;
        ResultSet resultSet = null;
        ArrayList<Seance> seances = new ArrayList<>();
        try {
            stmt = bdd_conn.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM seances");

            // Récupération des séances
            while (resultSet.next()) {
                int seanceID = resultSet.getInt("SeanceID");
                int filmID = resultSet.getInt("FilmID");
                String salle = resultSet.getString("Salle");
                int nbPlace = resultSet.getInt("NbrePlace");
                Timestamp dateHeure = resultSet.getTimestamp("DateHeure"); // Récupération de la date et de l'heure

                // Création du format de date et d'heure
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");

                // Conversion du Timestamp en chaînes de caractères pour la date et l'heure
                String formattedDate = dateFormat.format(dateHeure);
                String formattedTime = timeFormat.format(dateHeure);

                // Parcours du catalogue pour trouver le film recherché
                Film seanceFilm = null;
                for (Film film : catalogue) {
                    if (film.getId() == filmID) {
                        seanceFilm = film;
                        break; // Sortie de la boucle dès que le film est trouvé
                    }
                }

                if(seanceFilm != null) {
                    // Création d'un objet Seance et ajout à la liste
                    Seance seance = new Seance(seanceID, seanceFilm, salle, nbPlace, formattedDate, formattedTime);
                    seances.add(seance);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention de la séance: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return seances;
    }


    public static void updateSeance(Seance seance) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE seances SET FilmID=?, Salle=?, NbrePlace=?, DateHeure=? WHERE SeanceID=?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setInt(1, seance.getFilm().getId());
            pstmt.setString(2, seance.getSalle());
            pstmt.setInt(3, seance.getNbplace());

            // Conversion de la date et l'heure en Timestamp pour l'assigner au paramètre de requête
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
            Date parsedDate = (Date) dateFormat.parse(seance.getDate() + " " + seance.getHoraire());
            Timestamp timestamp = new Timestamp(parsedDate.getTime());
            pstmt.setTimestamp(4, timestamp);

            pstmt.setInt(5, seance.getId());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException | ParseException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de la séance: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static int createSeance(Seance seance) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        int newSeanceID = 0;
        try {
            // Préparation de la requête SQL d'insertion
            String query = "INSERT INTO seances (FilmID, Salle, NbrePlace, DateHeure) VALUES (?, ?, ?, ?)";
            pstmt = bdd_conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setInt(1, seance.getFilm().getId());
            pstmt.setString(2, seance.getSalle());
            pstmt.setInt(3, seance.getNbplace());

            // Conversion de la date et l'heure en Timestamp pour l'assigner au paramètre de requête
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
            Date parsedDate = dateFormat.parse(seance.getDate() + " " + seance.getHoraire());
            Timestamp timestamp = new Timestamp(parsedDate.getTime());
            pstmt.setTimestamp(4, timestamp);

            // Exécution de la requête
            pstmt.executeUpdate();

            // Récupération de l'ID de la nouvelle séance insérée
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                newSeanceID = generatedKeys.getInt(1);
            } else {
                throw new SQLException("la récupération de l'ID généré pour la séance.");
            }
        } catch (SQLException | ParseException e) {
            throw new RuntimeException("Erreur lors de la création de la séance: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return newSeanceID;
    }


    public static void deleteSeance(int seanceID) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL de suppression
            String query = "DELETE FROM seances WHERE SeanceID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation de la valeur du paramètre de la requête
            pstmt.setInt(1, seanceID);

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de la séance: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }


}
