package DAO;

import Model.Client;
import Model.Employe;
import Model.User;

import java.sql.*;
import java.util.ArrayList;

public abstract class UserDAO {
    public static ArrayList<Client> getAllClients(){
        Connection bdd_conn = DAOManager.getConnection();
        Statement stmt = null;
        ResultSet resultSet = null;
        ArrayList<Client> clients = new ArrayList<Client>();
        try{
            stmt = bdd_conn.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM users WHERE Type != 'employé'");

            // Récupération de la première ligne
            while (resultSet.next()) {
                int clientID = resultSet.getInt("ClientID");
                String nom = resultSet.getString("Nom");
                String prenom = resultSet.getString("Prenom");
                String login = resultSet.getString("Login");
                String mdp = resultSet.getString("MDP");
                float reducPerso = resultSet.getFloat("ReducPerso");
                String type = resultSet.getString("Type");

                clients.add(new Client(clientID, nom, prenom, login, mdp, new ArrayList<>(), type, reducPerso));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention des clients: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return clients;
    }

    public static Client getUser(int idUser){
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        ResultSet resultSet = null;
        Client client = null;
        try{
            String query = "SELECT * FROM users WHERE ClientID = ?";
            pstmt = bdd_conn.prepareStatement(query);
            pstmt.setInt(1, idUser);
            resultSet = pstmt.executeQuery();

            // Récupération de la première ligne
            if (resultSet.next()) {
                int clientID = resultSet.getInt("ClientID");
                String nom = resultSet.getString("Nom");
                String prenom = resultSet.getString("Prenom");
                String login = resultSet.getString("Login");
                String mdp = resultSet.getString("MDP");
                float reducPerso = resultSet.getFloat("ReducPerso");
                String type = resultSet.getString("Type");

                client = new Client(clientID, nom, prenom, login, mdp, new ArrayList<>(), type, reducPerso);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention de l'utilisateur: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return client;
    }

    public static void updateUser(User user) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE Users SET Nom = ?, Prenom = ?, Login = ?, MDP = ?, ReducPerso = ?, Type = ? WHERE ClientID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setString(1, user.getNomUser());
            pstmt.setString(2, user.getPrenomUser());
            pstmt.setString(3, user.getLoginUser());
            pstmt.setString(4, user.getMdpUser());
            if(user instanceof Client) {
                pstmt.setFloat(5, ((Client) user).getReducMembre());
                pstmt.setString(6, ((Client) user).getTypeMembre());
            } else {
                pstmt.setFloat(5, 0);
                pstmt.setString(6, "employé");
            }
            pstmt.setInt(7, user.getIdUser());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour de l'utilisateur: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static int createUser(User user) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        int newUserID = 0;
        try {
            // Préparation de la requête SQL d'insertion
            String query = "INSERT INTO users (Nom, Prenom, Login, MDP, ReducPerso, Type) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = bdd_conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setString(1, user.getNomUser());
            pstmt.setString(2, user.getPrenomUser());
            pstmt.setString(3, user.getLoginUser());
            pstmt.setString(4, user.getMdpUser());
            if(user instanceof Client) {
                pstmt.setFloat(5, ((Client) user).getReducMembre());
                pstmt.setString(6, ((Client) user).getTypeMembre());
            } else {
                pstmt.setFloat(5, 0);
                pstmt.setString(6, "employé");
            }

            // Exécution de la requête
            pstmt.executeUpdate();

            // Récupération de l'ID du nouveau film inséré
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                newUserID = generatedKeys.getInt(1);
            } else {
                throw new SQLException("la récupération de l'ID généré a échoué.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création de l'utilisateur: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return newUserID;
    }

    public static void deleteUser(int idUser) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL de suppression
            String query = "DELETE FROM users WHERE UserID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation de la valeur du paramètre de la requête
            pstmt.setInt(1, idUser);

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression de l'utilisateur: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static User authenticateUser(String login, String password) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        ResultSet resultSet = null;
        User user = null;
        try {
            // Préparation de la requête SQL de recherche de l'utilisateur
            String query = "SELECT * FROM users WHERE Login = ? AND MDP = ?";
            pstmt = bdd_conn.prepareStatement(query);
            pstmt.setString(1, login);
            pstmt.setString(2, password);

            // Exécution de la requête
            resultSet = pstmt.executeQuery();

            // Vérification si l'utilisateur existe
            if (resultSet.next()) {
                int clientID = resultSet.getInt("ClientID");
                String nom = resultSet.getString("Nom");
                String prenom = resultSet.getString("Prenom");
                float reducPerso = resultSet.getFloat("ReducPerso");
                String type = resultSet.getString("Type");

                // Si l'utilisateur est un employé
                if (type.equals("employé")) {
                    user = new Employe(clientID, nom, prenom, login, password);
                } else { // Si l'utilisateur est un client
                    user = new Client(clientID, nom, prenom, login, password, new ArrayList<>(), type, reducPerso);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'authentification de l'utilisateur: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return user;
    }

}
