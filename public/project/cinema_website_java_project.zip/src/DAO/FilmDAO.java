package DAO;

import Model.Film;

import java.sql.*;
import java.util.ArrayList;

public abstract class FilmDAO {
    public static ArrayList<Film> getAllFilms(){
        Connection bdd_conn = DAOManager.getConnection();
        Statement stmt = null;
        ResultSet resultSet = null;
        ArrayList<Film> catalogue = new ArrayList<Film>();
        try{
            stmt = bdd_conn.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM films");

            // Récupération du tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("FilmID");
                String image = resultSet.getString("Image");
                String titre = resultSet.getString("Titre");
                String realisateur = resultSet.getString("Realisateur");
                String duree = resultSet.getString("Duree");
                float prix = resultSet.getFloat("Prix");

                catalogue.add(new Film(id, image, titre, realisateur, duree, prix));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention des films: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return catalogue;
    }

    public static void updateFilm(Film film) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE Films SET Image = ?, Titre = ?, Realisateur = ?, Duree = ?, Prix = ? WHERE FilmID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setString(1, film.getImage());
            pstmt.setString(2, film.getTitre());
            pstmt.setString(3, film.getRealisateur());
            pstmt.setString(4, film.getDuree());
            pstmt.setFloat(5, film.getPrix());
            pstmt.setInt(6, film.getId());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du Film: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static int createFilm(Film film) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        int newfilmID = 0;
        try {
            // Préparation de la requête SQL d'insertion
            String query = "INSERT INTO Films (Image, Titre, Realisateur, Duree, Prix, CinemaID) VALUES (?, ?, ?, ?, ?, 1)";
            pstmt = bdd_conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setString(1, film.getImage());
            pstmt.setString(2, film.getTitre());
            pstmt.setString(3, film.getRealisateur());
            pstmt.setString(4, film.getDuree());
            pstmt.setFloat(5, film.getPrix());

            // Exécution de la requête
            pstmt.executeUpdate();

            // Récupération de l'ID du nouveau film inséré
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                newfilmID = generatedKeys.getInt(1);
            } else {
                throw new SQLException("la récupération de l'ID généré a échoué.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la création du Film: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return newfilmID;
    }

    public static void deleteFilm(int idFilm) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;
        try {
            // Préparation de la requête SQL de suppression
            String query = "DELETE FROM Films WHERE FilmID = ?";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation de la valeur du paramètre de la requête
            pstmt.setInt(1, idFilm);

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la suppression du film: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

}
