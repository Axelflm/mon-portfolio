package DAO;

import Model.Cinema;
import Model.Film;
import Model.Reductions;
import Model.Seance;

import java.sql.*;
import java.util.ArrayList;

public abstract class CinemaDAO {
    public static Cinema getCinema(){
        Connection bdd_conn = DAOManager.getConnection();
        Statement stmt = null;
        ResultSet resultSet = null;
        Cinema cinema = null;
        try{
            stmt = bdd_conn.createStatement();
            resultSet = stmt.executeQuery("SELECT * FROM cinema");

            // Récupération de la première ligne
            if (resultSet.next()) {
                String logo = resultSet.getString("Logo");
                String adresse = resultSet.getString("Adresse");
                String nom = resultSet.getString("Nom");

                float reducEnfants = resultSet.getFloat("ReducEnfants");
                float reducRegulier = resultSet.getFloat("ReducRegulier");
                float reducSenior = resultSet.getFloat("ReducSenior");
                Reductions reductions = new Reductions(reducEnfants, reducRegulier, reducSenior);

                ArrayList<Film> catalogue = new ArrayList<Film>();
                ArrayList<Seance> seances = new ArrayList<Seance>();

                cinema = new Cinema(logo, adresse, nom, reductions, catalogue, seances);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de l'obtention du cinéma: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (resultSet != null) resultSet.close();
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
        return cinema;
    }

    public static void updateCinema(Cinema cinema) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;

        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE cinema SET Logo = ?, Adresse = ?, Nom = ? WHERE CinemaID = 1";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setString(1, cinema.getLogo());
            pstmt.setString(2, cinema.getAdresse());
            pstmt.setString(3, cinema.getNom());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du cinéma: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

    public static void updateReduction(Reductions reductions) {
        Connection bdd_conn = DAOManager.getConnection();
        PreparedStatement pstmt = null;

        try {
            // Préparation de la requête SQL d'update
            String query = "UPDATE cinema SET ReducEnfants = ?, ReducRegulier = ?, ReducSenior = ? WHERE CinemaID = 1";
            pstmt = bdd_conn.prepareStatement(query);

            // Assignation des valeurs aux paramètres de la requête
            pstmt.setFloat(1, reductions.getReducEnfants());
            pstmt.setFloat(2, reductions.getReducRegulier());
            pstmt.setFloat(3, reductions.getReducSenior());

            // Exécution de la requête
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erreur lors de la mise à jour du cinéma: " + e.getMessage());
        } finally {
            // Fermeture des ressources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException e) {
                System.out.println("Erreur SQL: " + e.getMessage());
            }
        }
    }

}
