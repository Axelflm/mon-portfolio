package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAOManager {
    private static DAOManager daoManager;
    // Informations de connexion à la base de données
    private static final String bdd_url = "jdbc:mysql://localhost:3306/cinema42";
    private static final String bdd_login = "root";
    private static final String bdd_mdp = "";
    private Connection bdd_conn;

    // Constructeur privé
    private DAOManager() {
        // Initialisation de la connection a la bdd
        try {
            // Chargement du driver JDBC pour MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Création de la connexion
            bdd_conn = DriverManager.getConnection(bdd_url, bdd_login, bdd_mdp);
            System.out.println("Connexion à la base de données établie.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erreur lors de la connexion à la base de données : " + e.getMessage());
        }
    }

    // Méthode pour obtenir l'instance unique //package protected méthode
    static synchronized Connection getConnection() {
        if (daoManager == null) {
            daoManager = new DAOManager();
        }
        return daoManager.bdd_conn;
    }

    // Méthode pour fermer la connexion à la base de données
    public static void closeConnection() {
        if (daoManager != null && DAOManager.getConnection() != null) {
            try {
                DAOManager.getConnection().close();
                System.out.println("Connexion à la base de données fermée.");
            } catch (SQLException e) {
                System.out.println("Erreur lors de la fermeture de la connexion à la base de données : " + e.getMessage());
            }
        }
    }
}
