-- Adminer 4.8.1 MySQL 8.0.31 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `cinema42`;
CREATE DATABASE `cinema42` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `cinema42`;

DROP TABLE IF EXISTS `cinema`;
CREATE TABLE `cinema` (
  `CinemaID` int NOT NULL AUTO_INCREMENT,
  `Logo` varchar(255) DEFAULT NULL,
  `Nom` varchar(255) DEFAULT NULL,
  `ReducRegulier` float DEFAULT NULL,
  `ReducSenior` float DEFAULT NULL,
  `ReducEnfants` float DEFAULT NULL,
  `Adresse` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CinemaID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cinema` (`CinemaID`, `Logo`, `Nom`, `ReducRegulier`, `ReducSenior`, `ReducEnfants`, `Adresse`) VALUES
(1,	'img/ece.jpg',	'ECE-Cinéma 42',	0.1,	0.3,	0.5,	'10 rue Sextius Michel 75015 Paris France');

DROP TABLE IF EXISTS `films`;
CREATE TABLE `films` (
  `FilmID` int NOT NULL AUTO_INCREMENT,
  `Image` varchar(255) DEFAULT NULL,
  `Titre` varchar(255) DEFAULT NULL,
  `Realisateur` varchar(255) DEFAULT NULL,
  `Duree` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_as_cs DEFAULT NULL,
  `Prix` float DEFAULT NULL,
  `CinemaID` int DEFAULT NULL,
  PRIMARY KEY (`FilmID`),
  KEY `CinemaID` (`CinemaID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `films` (`FilmID`, `Image`, `Titre`, `Realisateur`, `Duree`, `Prix`, `CinemaID`) VALUES
(1,	'img/Avatar2.jpg',	'Avatar : la voie de l\'eau',	'James Cameron',	'3h12min',	12.99,	1),
(2,	'img/oppenheimer.jpg',	'Oppenheimer',	'Christopher Nolan',	'3h01min',	12.99,	1),
(3,	'img/kungFuPanda4.jpg',	'Kung Fu Panda 4',	'Mike Mitchell',	'1h34min',	9.99,	1),
(4,	'img/GodzillaXKong.jpg',	'Godzilla x Kong : Le Nouvel Empire',	'Adam Wingard',	'1h55min',	12.99,	1),
(5,	'img/SOSFantomes.jpg',	'S.O.S. Fantômes : La Menace de glace',	'Gil Kenan',	'1h56min',	11.99,	1),
(6,	'img/Dune2.jpg',	'Dune : Deuxième Partie',	'Denis Villeneuve',	'2h46min',	13.99,	1);

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `ReservationID` int NOT NULL AUTO_INCREMENT,
  `ClientID` int DEFAULT NULL,
  `SeanceID` int DEFAULT NULL,
  `NbBillets` int DEFAULT NULL,
  `TotalPaiement` float DEFAULT NULL,
  PRIMARY KEY (`ReservationID`),
  KEY `ClientID` (`ClientID`),
  KEY `SeanceID` (`SeanceID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `reservations` (`ReservationID`, `ClientID`, `SeanceID`, `NbBillets`, `TotalPaiement`) VALUES
(1,	6,	1,	1,	12.99),
(2,	6,	6,	2,	25.98),
(3,	2,	3,	4,	20.78),
(4,	2,	5,	2,	9.59),
(5,	3,	4,	3,	27.28),
(6,	3,	2,	3,	20.98);

DROP TABLE IF EXISTS `seances`;
CREATE TABLE `seances` (
  `SeanceID` int NOT NULL AUTO_INCREMENT,
  `FilmID` int DEFAULT NULL,
  `Salle` varchar(255) DEFAULT NULL,
  `NbrePlace` int DEFAULT NULL,
  `DateHeure` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`SeanceID`),
  KEY `FilmID` (`FilmID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `seances` (`SeanceID`, `FilmID`, `Salle`, `NbrePlace`, `DateHeure`) VALUES
(1,	1,	'Salle 5',	180,	'2024-04-13 17:40:00'),
(2,	3,	'Salle 3',	100,	'2024-04-12 15:30:00'),
(3,	2,	'Salle 2',	200,	'2024-04-11 18:00:00'),
(4,	1,	'Salle 1',	150,	'2024-04-10 16:00:00'),
(5,	5,	'Salle 5',	250,	'2024-04-14 19:00:00'),
(6,	4,	'Salle 6',	125,	'2024-04-17 17:30:00');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ClientID` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) DEFAULT NULL,
  `Prenom` varchar(255) DEFAULT NULL,
  `Login` varchar(255) DEFAULT NULL,
  `MDP` varchar(255) DEFAULT NULL,
  `ReducPerso` float DEFAULT NULL,
  `Type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`ClientID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`ClientID`, `Nom`, `Prenom`, `Login`, `MDP`, `ReducPerso`, `Type`) VALUES
(2,	'Garcia',	'Maria',	'maria_garcia',	'mdp123',	0.1,	'enfant'),
(1,	'Administrateur',	'',	'admin',	'admin',	0,	'employé'),
(3,	'Dubois',	'Sophie',	'sophie_dubois',	'secure789',	0.2,	'régulier'),
(4,	'Müller',	'Hans',	'hans_mueller',	'password123',	0.25,	'sénior'),
(5,	'Rossi',	'Giulia',	'giulia_rossi',	'psw567',	0,	'employé'),
(6,	'Gérard',	'Ducloc',	'',	'',	0,	'invité');

-- 2024-04-18 17:19:51